local Proxy = module("vrp", "lib/Proxy")
local Tunnel = module("vrp", "lib/Tunnel")

vRP = Proxy.getInterface("vRP")

Svmtfa = {}
Tunnel.bindInterface("jobEtno", Svmtfa)
Proxy.addInterface("jobEtno", Svmtfa)
ClTbco = Tunnel.getInterface("jobEtno", "jobEtno")

collects = {
}
print("aa")

function Svmtfa.canCollect(what)
    if collects[what] == nil or collects[what] == false then
        collects[what] = true

        return true
    else
        return false
    end
end

function Svmtfa.colecteazaPlanta(what)
    print("aadsds")
    TriggerClientEvent("syncplant1", -1, what, true)
    collects[what] = true
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "marijuana", 1, true })
    Wait(30000)
    collects[what] = false
    TriggerClientEvent("syncplant1", -1, what, false)
end

function Svmtfa.hasItems(ce,cat)
    print("aaa")
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), ce, cat, true }) then
        return true
    end
    return false
end

function Svmtfa.finishedMarijuana()
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "marijuana1g", 1, true })
end

function Svmtfa.hasItemsPulse()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "ots", 1, true }) and vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "ingr", 1, true }) then
        return true
    end
    return false
end
function Svmtfa.hasItemsGold()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "Acetona", 1, true }) and vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "ingr", 1, true }) then
        return true
    end
    return false
end

function Svmtfa.proceseazaPulse()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "Pulse", 1, true })
end

function Svmtfa.hasItemsCutie()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "trabuc", 1, true }) and
        vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "cutie", 1, true }) then
        return true
    end
    return false
end

function Svmtfa.proceseazaCutia()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cutietrabuc", 1, true })
end
