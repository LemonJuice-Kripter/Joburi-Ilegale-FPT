local jobEtno, jobEtnoS = {}, Tunnel.getInterface("jobEtno", "jobEtno")
local jobEtnoF = {}
local canDoJob = false

local coordsLivrare = {
      {-948.3505859375,-1107.7459716796,2.1718497276306},
	  {-930.23406982422,-1101.0979003906,2.1718475818634},
	  {-946.63366699218,-1051.301147461,2.1718463897706},
	  {-967.2958984375,-1080.2860107422,2.1718463897706},
	  {-946.20611572266,-1122.9603271484,2.1503412723542},
	  {-982.59045410156,-1083.5920410156,2.5448005199432},
	  {-970.60186767578,-1121.005859375,2.1718454360962},
	  {-975.68182373046,-1139.9654541016,2.3447561264038},
	  {-1024.4490966796,-1139.6785888672,2.7453286647796},
	  {-1048.0983886718,-1123.2690429688,2.1585943698884},
	  {-1032.5065917968,-1172.845703125,2.1585965156556},
	  {-1055.0228271484,-1133.9615478516,2.1587963104248},
	  {-1063.883178711,-1133.471069336,2.158597946167},
	  {-1063.5362548828,-1160.3298339844,2.7514245510102},
	  {-1091.3048095704,-1145.299194336,2.1585965156556},
	  {-1122.6909179688,-1089.3952636718,2.5452535152436},
	  {-1134.1451416016,-1050.1540527344,2.1503558158874},
	  {-1122.1458740234,-1046.25,2.1503562927246},
	  {-1104.0500488282,-1059.9946289062,2.7325546741486},
	  {-1108.7468261718,-1040.9064941406,2.150356054306},
	  {-1097.1843261718,-1033.1192626954,2.150354385376},
	  {-1065.704711914,-1055.4932861328,6.4116621017456},
	  {-1076.2430419922,-1026.918334961,4.5449323654174},
	  {-1041.648803711,-1025.8045654296,2.7483654022216},
	  {-1054.0725097656,-1000.1262207032,6.410490512848},
	  {-1008.7414550782,-1036.0537109375,2.1503562927246},
	  {-1000.3457641602,-1030.0192871094,2.1503081321716},
	  {-1008.5206298828,-1015.3732299804,2.1503095626832},
	  {-1027.5676269532,-969.41632080078,2.5160133838654},
	  {-1018.4411621094,-964.16131591796,2.5248363018036},
	  {-1012.3497924804,-982.85247802734,2.1503083705902},
	  {-997.31951904296,-1012.3176269532,2.1503088474274},
	  {-995.46508789062,-967.3251953125,2.54536485672},
	  {-990.5380859375,-975.81561279296,4.2226877212524},
	  {-968.02807617188,-1008.8442993164,2.3453273773194},
	  {-978.662109375,-990.78924560546,4.5449948310852},
	  {-1235.603515625,-1191.5026855468,7.6724429130554},
	  {-1241.6811523438,-1208.454711914,8.5190238952636},
	  {-1243.8392333984,-1241.0046386718,11.027709960938},
	  {-1229.5144042968,-1235.8035888672,11.027696609498},
	  {-1229.2325439454,-1243.5944824218,7.0330700874328},
	  {-1323.8359375,-1236.5809326172,4.6228637695312},
	  {-1306.4677734375,-1226.6193847656,8.9804782867432},
	  {-1300.5861816406,-1233.5087890625,4.4863419532776},
	  {-1293.0548095704,-1259.4412841796,4.1980180740356},
	  {-1321.6197509766,-1264.1771240234,4.5916895866394},
	  {-1318.5084228516,-1271.291015625,9.0925989151},
	  {-1309.947631836,-1317.7341308594,4.873061656952},
	  {-1271.6770019532,-1297.5205078125,8.2858963012696},
	  {-1269.9896240234,-1296.3275146484,4.0039381980896},
	  {-1287.3232421875,-1327.7877197266,4.1900200843812},
	  {-1256.2481689454,-1359.830078125,4.0364956855774},
	  {-1273.2474365234,-1371.9226074218,4.3026323318482},
	  {-1247.0396728516,-1358.3016357422,7.8204183578492},
	  {-1202.1951904296,-1308.4128417968,4.916615486145},
	  {-1194.006225586,-1298.5793457032,5.1722412109375},
	  {-1224.4670410156,-1331.055053711,4.2289724349976},
	  {-1170.9067382812,-1380.9093017578,4.9702138900756},
	  {-1185.990234375,-1385.8387451172,4.6211614608764},
	  {-1157.6412353516,-1451.6444091796,4.4772691726684},
	  {-1152.014038086,-1447.5389404296,4.7102680206298},
	  {-1147.6885986328,-1452.0167236328,4.5892419815064},
	  {-1132.5908203125,-1433.96875,5.0344586372376},
	  {-1126.1101074218,-1447.263671875,5.055461883545},
	  {-1120.2684326172,-1449.2838134766,5.0418257713318},
	  {-1133.013305664,-1456.287109375,4.868155002594},
	  {-1142.328491211,-1461.1575927734,4.6251301765442},
	  {-1146.0079345704,-1466.4357910156,7.6907062530518},
	  {-1112.740234375,-1487.8896484375,4.89280128479},
	  {-1109.1444091796,-1482.4114990234,4.9281249046326},
	  {-1102.4556884766,-1491.9388427734,4.8868618011474},
	  {-1111.1413574218,-1497.9344482422,4.673131942749},
	  {-1116.9271240234,-1505.6248779296,4.394519329071},
	  {-1121.4030761718,-1493.878540039,4.6619358062744},
	  {-1101.9049072266,-1536.7951660156,4.5795683860778},
	  {-1087.4239501954,-1529.1861572266,4.6960010528564},
	  {-1090.8907470704,-1517.2292480468,4.8329300880432},
	  {-1085.861694336,-1503.8916015625,5.7074356079102},
	  {-1144.0827636718,-1528.9178466796,4.3446769714356},
	  {-1161.552368164,-1532.6577148438,4.5370950698852},
	  {-1155.787475586,-1543.0102539062,4.4445934295654},
	  {-1147.0280761718,-1562.015625,4.4021997451782},
	  {-1131.072265625,-1551.7637939454,4.5847840309144},
	  {-1072.7298583984,-1561.9022216796,4.888216495514},
	  {-1072.1856689454,-1565.8374023438,4.3706798553466},
	  {-1064.0144042968,-1557.1236572266,5.1417818069458},
	  {-1057.0770263672,-1551.1918945312,4.9170532226562},
	  {-1032.1838378906,-1582.5482177734,5.2689266204834},
	  {-1041.5517578125,-1590.5528564454,4.9932789802552},
	  {-1043.3341064454,-1580.4171142578,5.03892660141},
	  {-1049.1518554688,-1581.0909423828,4.983558177948},
	  {-1057.0598144532,-1587.3995361328,4.6072535514832},
	  {-1065.1511230468,-1586.1165771484,4.4327178001404},
	  {-1032.0297851562,-1620.0864257812,5.1087908744812},
	  {-1023.5534057618,-1614.3344726562,5.0884351730346},
	  {-1030.150390625,-1604.3413085938,5.0895729064942},
	  {-1039.1085205078,-1610.3681640625,5.11164188385},
	  {-1129.8188476562,-1604.3552246094,4.3984236717224},
	  {-1105.5451660156,-1596.9604492188,4.6145482063294},
	  {-1118.4093017578,-1619.0168457032,4.3984279632568},
	  {-1117.375366211,-1627.1765136718,4.4782929420472},
	  {-1093.491821289,-1608.109008789,8.4588441848754},
	  {-1108.2271728516,-1637.5443115234,4.6159610748292},
	  {-1087.1826171875,-1614.746459961,4.7264132499694},
	  {-1088.4267578125,-1623.013305664,4.7327313423156},
	  {-1082.525756836,-1631.1755371094,4.739649772644},
	  {-1075.7774658204,-1638.2200927734,4.5012035369874},
	  {-1071.3967285156,-1639.9897460938,4.853859424591},
	  {-1075.3489990234,-1644.980102539,4.5012063980102},
	  {-1069.902709961,-1653.1345214844,4.4280190467834},
	  {-1068.5859375,-1648.1623535156,4.8561644554138},
	  {-1088.4821777344,-1672.1569824218,4.7000160217286},
	  {-1059.8752441406,-1658.640625,4.6731462478638}
}


local hasJob = false
local showedLivrare = false
local sitting = false
local scaunAles = nil

local scaune = { 
    [1] = {
        coords = vector3(5071.3530273438,-4600.75390625,1.8611805438995),
    },
    [2] = {
        coords = vector3(5152.0727539062,-4672.71875,1.4399992227554),
    },
    [3] = {
        coords = vector3(5152.9716796875,-4670.2705078125,1.4399992227554),
    },
    [4] = {
        coords = vector3(5153.6977539062,-4668.7958984375,1.4399992227554),
    }
}

local showedScaune = {}

for k,_ in pairs(scaune) do 
    showedScaune[k] = false
end

RegisterNetEvent("vRP:onJobChange")
AddEventHandler("vRP:onJobChange", function(job)
    job = job
    if job == 'Traficant de Etnobotanice' then
        canDoJob = true
    else
        canDoJob = false
        hasJob = false
        if blip then
            RemoveBlip(blip)
        end
    end
end)

RegisterNetEvent("fpt-etno:client:info")
AddEventHandler("fpt-etno:client:info", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Ai nevoie de ingrasamant chimic, acetona si otrava de sobolani sa poti sa faci etnobotanice.', 7500, 'Mustata')
end)

RegisterNetEvent("fpt-etno:client:gps")
AddEventHandler("fpt-etno:client:gps", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'O sa primesti o locatie pe GPS!', 7500, 'Mustata')
	SetNewWaypoint(2747.5100097656,3472.8933105469)
end)
	
RegisterNetEvent("fpt-etno:client:locatie")
AddEventHandler("fpt-etno:client:locatie", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Nu, saptamanal se inchiriaza la niste baieti smecheri care au bani la care trebuie sa platesti taxe.', 7500, 'Mustata')
end)
	
RegisterNetEvent("fpt-etno:client:alexia")
AddEventHandler("fpt-etno:client:alexia", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Mi se spune Mustata, ma ocup de locatia asta. Mai ai multe intrebari?', 7500, 'Mustata')
end)

RegisterNetEvent("fpt-etno:client:addGroup")
AddEventHandler("fpt-etno:client:addGroup", function()
    jobEtnoS.setJob{true}
end)

RegisterNetEvent("fpt-etno:client:removeGroup")
AddEventHandler("fpt-etno:client:removeGroup", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Pacat... Sa inteleg ca nu iti plac banii?', 7500, 'Mustata')
    jobEtnoS.setJob{false}
end)
canDoJob = true
CreateThread(function()
    while true do
        Citizen.Wait(0)
        if canDoJob then
            inRange = false
            local pdist

            for k,v in pairs(scaune) do
                pdist = getPlayerPosition(v.coords)
                if pdist < 1.5 and not sitting then
                    if not showedScaune[k] then
                        exports['fpt-textui']:Open('[E] Aseaza-te', 'darkblue', 'left')
                        showedScaune[k] = true
                    end
                    inRange = true
                    if IsControlJustPressed(0,38) then
                      
                                exports['fpt-textui']:Close()
                                sitting = true
                                TaskPlayAnim("random@shop_tattoo", "_idle_a", 2.0, 2.0, -1, 51, 0, false, false, false)
                                FreezeEntityPosition(PlayerPedId(), true)
                                TriggerEvent("mt:missiontext", "~r~[C]~w~ Pulse | ~r~[G]~w~ Special Gold", 15000)
                                scaunAles = k
                                CreateThread(function()
                                    while sitting do Wait(5)
                                        DisableAllControlActions(0)
                                        for i=1, 7 do
                                            EnableControlAction(0, i)
                                        end
                                    end
                                end)
                        
                    end
                else
                    if showedScaune[k] and not sitting then
                        exports['fpt-textui']:Close()
                        showedScaune[k] = false
                    end
                end
            end

            if sitting then
                inRange = true                
                if IsDisabledControlJustPressed(0,38) then
       
                    exports['fpt-textui']:Close()
                    sitting = false
                    FreezeEntityPosition(PlayerPedId(), false)
                    ClearPedTasks(PlayerPedId())
                end

                if IsDisabledControlJustPressed(0, 26) then
                    jobEtnoF:proceseazaPulse(scaunAles)
                end

                if IsDisabledControlJustPressed(0, 47) then
                    jobEtnoF:proceseazaGold(scaunAles)
                end

                if getPlayerPosition(scaune[scaunAles].coords) > 2 then
 
                    exports['fpt-textui']:Close()
                    sitting = false
                    FreezeEntityPosition(PlayerPedId(), false)
                    ClearPedTasks(PlayerPedId())
                end
            end
                
            if not hasJob then
                jobEtnoF:setUpJob()
            else
                local distLivrare = getPlayerPosition(position)
                if distLivrare < 10 then
                    inRange = true
                    DrawMarker(20,position.x,position.y,position.z + 0.1,0,0,0,0,0,0,0.35,0.35,-0.60,230,0,0,85,0)
                end
                if distLivrare < 2 then
                    inRange = true
                    if not showedLivrare then
                        exports['fpt-textui']:Open('[E] Bate la usa', 'darkblue', 'left')
                        showedLivrare = true
                    end
                    if IsControlJustPressed(0,38) then
                        jobEtnoF:livreaza()
                        exports['fpt-textui']:Close()
                    end
                else
                    if showedLivrare then
                        exports['fpt-textui']:Close()
                        showedLivrare = false
                    end
                end
            end
            
            if not inRange then
                Citizen.Wait(1000)
            end
        else
            Citizen.Wait(5000)
        end
    end
end)

function jobEtnoF:livreaza()
    jobEtnoS.hasItemsLivrare({livratItems}, function (has)
        if has then
            exports['progressBars']:startUI(15000, "Livrezi...")
            local hash = GetHashKey("prop_meth_bag_01")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(100)
                RequestModel(hash)
            end
            playAnim("timetable@jimmy@doorknock@", "knockdoor_idle", 2.0, 2.0, 5000, 51, 0, false, false, false)
            Citizen.Wait(5000)
            playAnim("anim@mugging@victim@toss_ped@", "throw_object_right_pocket_male", 2.0, 2.0, 2000, 51, 0, false, false, false)
            Citizen.Wait(300)
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.07, -0.01, -0.04, 0.0, 0.0, 190.0, true, true, false, false, 1, true)
            Citizen.Wait(1700)
            playAnim("tunf_iaa_mcs1-1", "mp_m_freemode_01^3_dual-1", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(3000)
            playAnim("mp_common", "givetake1_b", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(1500)
            DeleteObject(prop)
            Citizen.Wait(3500)
            
            hasJob = false
            jobEtnoS.livreaza{livratItems}
            ClearPedTasks(PlayerPedId())
        else
            TriggerEvent('fplaytbank:notifications', 'error', 'Nu ai marfa la tine!', 7500, 'Client')    
        end
    end)
end

function jobEtnoF:setUpJob()
    hasJob = true
    if blip then
        RemoveBlip(blip)
    end
    local x,y,z = table.unpack(coordsLivrare[math.random(1,#coordsLivrare)])
    position = vector3(x,y,z)
    blip = AddBlipForCoord(position.x,position.y,position.z)
	SetBlipAsShortRange(blip, true)
	SetBlipRoute(blip, true)
	SetBlipScale(blip, 0.6)
	SetBlipSprite(blip, 501)
	SetBlipColour(blip, 24)
	SetBlipRouteColour(blip, 24)
    livratItems = {
        ['pulse'] = math.random(1,4),
        ['specialgold'] = math.random(1,4)
    }
    strada = GetStreetNameAtCoord(position.x, position.y, position.z, Citizen.ResultAsInteger(), Citizen.ResultAsInteger())
    numeStrada = GetStreetNameFromHashKey(strada)
    jobEtnoS.trimiteMail(livratItems, numeStrada)
end

function jobEtnoF:proceseazaPulse(scaun)
    jobEtnoS.hasItemsPulse({}, function (has)
        if has then
            local animDict = "anim@amb@business@coc@coc_unpack_cut_left@"
            exports['progressBars']:startUI(5000, "Procesezi Etnobotanice...")
            ClearPedTasksImmediately(PlayerPedId())
            playAnim(animDict, "coke_cut_coccutter", 2.0, 2.0, 5000, 2, 0, false, false, false)
            local hash = GetHashKey("prop_cs_credit_card")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(100)
                RequestModel(hash)
            end
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.05, -0.01, -0.04, 13.0, 0.0, 90.0, true, true, false, false, 1, true)
            local prop2 = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop2, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 18905), 0.14, 0.08, 0.07, 13.0, 0.0, 90.0, true, true, false, false, 1, true)
            Citizen.Wait(5000)
            DeleteObject(prop)
            DeleteObject(prop2)
            jobEtnoS.proceseazaPulse{scaun}
        else 
            TriggerEvent("fplaytbank:notifications", 'error', 'Nu ai materialele necesare [1x Otrava Sobolani, 1x Ingrasamant Chimic]', 7500, 'FPlayT')
        end
    end)
end

function jobEtnoF:proceseazaGold(scaun)
    jobEtnoS.hasItemsGold({}, function (has)
        if has then
            local animDict = "anim@amb@business@coc@coc_unpack_cut_left@"
            exports['progressBars']:startUI(5000, "Procesezi Etnobotanice...")
            ClearPedTasksImmediately(PlayerPedId())
            playAnim(animDict, "coke_cut_coccutter", 2.0, 2.0, 5000, 2, 0, false, false, false)
            local hash = GetHashKey("prop_cs_credit_card")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(100)
                RequestModel(hash)
            end
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.05, -0.01, -0.04, 13.0, 0.0, 90.0, true, true, false, false, 1, true)
            local prop2 = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop2, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 18905), 0.14, 0.08, 0.07, 13.0, 0.0, 90.0, true, true, false, false, 1, true)
            Citizen.Wait(5000)
            DeleteObject(prop)
            DeleteObject(prop2)
            jobEtnoS.proceseazaPulse{scaun}
        else 
            TriggerEvent("fplaytbank:notifications", 'error', 'Nu ai materialele necesare [1x Acetona, 1x Ingrasamant Chimic]', 7500, 'FPlayT')
        end 
    end)
end

function jobEtno.shake(tip, intensitate)
    ShakeGameplayCam(tip, intensitate)
end

function jobEtno.stopShake()
    StopGameplayCamShaking()
end

Tunnel.bindInterface("jobEtno", jobEtno)