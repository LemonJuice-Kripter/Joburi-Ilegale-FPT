local jobMarijuana, jobMarijuanaS = {}, Tunnel.getInterface("jobMarijuana", "jobMarijuana")
local jobMarijuanaF = {}
local canDoJob = true

local coordsLivrare = {
      {52.851974487304,-1440.1209716796,29.311752319336},
	  {3.3426406383514,-1430.4411621094,30.95555305481},
	  {-32.388263702392,-1432.757446289,31.88256072998},
	  {-36.784580230712,-1492.0286865234,31.21870803833},
	  {-48.088607788086,-1431.0942382812,32.4208984375},
	  {-53.219173431396,-1523.6593017578,33.436126708984},
	  {-77.68113708496,-1515.2395019532,34.245338439942},
	  {-36.099655151368,-1536.9099121094,31.452383041382},
	  {-24.74412727356,-1556.9428710938,30.686845779418},
	  {-113.39380645752,-1467.760131836,33.822689056396},
	  {-132.42474365234,-1462.7017822266,33.822673797608},
	  {-82.927040100098,-1399.3450927734,29.322010040284},
	  {-184.46742248536,-1539.4464111328,34.359642028808},
	  {-192.16375732422,-1559.8914794922,34.954643249512},
	  {-215.75680541992,-1576.2890625,34.869312286376},
	  {-212.89453125,-1618.1755371094,34.869312286376},
	  {-212.27842712402,-1660.6204833984,34.463180541992},
	  {-224.37631225586,-1674.4119873046,34.46336364746},
	  {-148.00035095214,-1687.4862060546,33.067474365234},
	  {-131.66105651856,-1665.5991210938,32.56432723999},
	  {-128.96932983398,-1647.2684326172,33.303493499756},
	  {-105.5778503418,-1632.5798339844,32.906898498536},
	  {-80.271347045898,-1607.9206542968,31.480659484864},
	  {-42.767475128174,-1859.3364257812,26.197551727294},
	  {2.889463186264,-1893.0931396484,23.69595336914},
	  {30.562379837036,-1923.8592529296,21.95694732666},
	  {64.205261230468,-1948.166381836,21.368528366088},
	  {75.699073791504,-1969.9832763672,21.129880905152},
	  {113.4665222168,-1973.9783935546,21.320526123046},
	  {131.65132141114,-1961.5677490234,18.863147735596},
	  {159.58526611328,-1933.423461914,20.229991912842},
	  {182.84085083008,-1918.498413086,22.360551834106},
	  {66.41300201416,-1868.6416015625,22.798385620118},
	  {39.556594848632,-1844.9822998046,24.058811187744},
	  {30.179162979126,-1824.1251220704,24.752111434936},
	  {6.3422837257386,-1816.515625,25.352928161622},
	  {-46.19928741455,-1771.5848388672,28.295700073242},
	  {219.65274047852,-1885.5103759766,25.708978652954},
	  {196.99081420898,-1871.8967285156,25.05586051941},
	  {171.09698486328,-1852.5046386718,24.263977050782},
	  {143.36946105958,-1857.9790039062,24.376541137696},
	  {162.56031799316,-1830.6047363282,27.857975006104},
	  {183.02589416504,-1836.4968261718,28.10274887085},
	  {195.34414672852,-1841.9799804688,28.023115158082},
	  {206.53329467774,-1851.4881591796,27.481143951416},
	  {292.72705078125,-1905.9797363282,27.267641067504},
	  {279.25689697266,-1919.418334961,26.169750213624},
	  {269.84716796875,-1932.9213867188,25.43618774414},
	  {255.85006713868,-1946.7564697266,24.691848754882},
	  {200.02479553222,-2002.1945800782,18.86157798767},
	  {188.93870544434,-2019.0224609375,18.288722991944},
	  {220.70268249512,-2032.6697998046,18.391542434692},
	  {240.69822692872,-2021.5483398438,18.70725440979},
	  {250.2153930664,-2006.2136230468,20.208574295044},
	  {269.31146240234,-1985.1607666016,20.80266571045},
	  {274.58364868164,-1968.8712158204,23.003393173218},
	  {286.7573852539,-1963.8498535156,22.90087890625},
	  {299.43493652344,-1940.4412841796,24.24179649353},
	  {307.1078491211,-1932.0642089844,24.831867218018},
	  {337.62759399414,-1991.6218261718,24.046068191528},
	  {335.80004882812,-2010.9440917968,22.313125610352},
	  {363.45336914062,-1999.0012207032,24.245637893676},
	  {392.67837524414,-2017.2229003906,23.403093338012},
	  {371.43353271484,-2040.674194336,22.196100234986},
	  {372.5180053711,-2056.0114746094,21.744470596314},
	  {345.49310302734,-2067.5935058594,20.936424255372},
	  {325.61895751954,-2050.8842773438,20.936391830444},
	  {293.29592895508,-2044.1662597656,19.646377563476},
	  {295.06518554688,-2067.6955566406,17.64946937561},
	  {321.07934570312,-2060.9812011718,20.939432144166},
	  {330.1062927246,-2095.3718261718,18.244068145752},
	  {420.30526733398,-2064.3205566406,22.13412475586},
	  {447.39685058594,-1896.9631347656,26.696668624878},
	  {494.53381347656,-1832.204711914,28.44923210144},
	  {524.38397216796,-1822.2591552734,28.50295829773},
	  {524.23547363282,-1795.9682617188,28.911869049072},
	  {528.16204833984,-1776.4709472656,28.505554199218},
	  {550.40808105468,-1775.5111083984,29.312126159668},
	  {449.9711303711,-1760.3286132812,28.959804534912},
	  {457.07891845704,-1747.2274169922,28.703643798828},
	  {465.58697509766,-1731.9299316406,29.152284622192},
	  {478.17245483398,-1710.3796386718,29.706226348876},
	  {453.58917236328,-1714.4608154296,29.709335327148},
	  {439.9758605957,-1727.8216552734,29.600160598754},
	  {416.21591186524,-1759.9034423828,29.707416534424},
	  {424.34420776368,-1819.4753417968,28.344913482666},
	  {417.76513671875,-1832.570678711,28.46280670166},
	  {390.79333496094,-1861.7683105468,26.714614868164},
	  {351.6614074707,-1888.6145019532,24.986938476562},
	  {324.810546875,-1866.1459960938,27.503807067872},
	  {345.25332641602,-1849.8992919922,27.308853149414},
	  {369.29803466796,-1829.8231201172,29.016422271728},
	  {380.67749023438,-1813.275756836,29.047771453858},
	  {398.20733642578,-1789.737915039,29.169731140136},
	  {375.9627380371,-1873.7846679688,26.031131744384}
}

local hasJob = false

RegisterNetEvent("vRP:onJobChange")
AddEventHandler("vRP:onJobChange", function(job)
    job = job
    if job == 'Traficant de Marijuana' then
        canDoJob = true
    else
        canDoJob = false
        hasJob = false
        if blip then
            RemoveBlip(blip)
        end
    end
end)

RegisterNetEvent("fpt-marijuana:client:angajat1")
AddEventHandler("fpt-marijuana:client:angajat1", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Lucrez pentru Grasu puiule, ma ocup de plantatiile de Marijuana.', 7500, 'Hallu')
end)
    
RegisterNetEvent("fpt-marijuana:client:angajat2")
AddEventHandler("fpt-marijuana:client:angajat2", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Vorbeste cu Grasu puiule, il gasesti in birou.', 7500, 'Hallu')
end)

RegisterNetEvent("fpt-marijuana:client:info")
AddEventHandler("fpt-marijuana:client:info", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Ai nevoie de Planta de Marijuana si Folie de Plastic.', 7500, 'Grasu')
end)

RegisterNetEvent("fpt-marijuana:client:gps")
AddEventHandler("fpt-marijuana:client:gps", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'De pe campurile din centru insulei. O sa primesti o locatie pe GPS!', 7500, 'Grasu')
	SetNewWaypoint(5374.8647460938,-5254.5698242188)
end)
	
RegisterNetEvent("fpt-marijuana:client:locatie")
AddEventHandler("fpt-marijuana:client:locatie", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Nu, saptamanal se inchiriaza la niste baieti smecheri care au bani la care trebuie sa platesti taxe.', 7500, 'Grasu')
end)
	
RegisterNetEvent("fpt-marijuana:client:alexia")
AddEventHandler("fpt-marijuana:client:alexia", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Mi se spune Grasu, ma ocup de locatia asta. Mai ai multe intrebari?', 7500, 'Grasu')
end)

RegisterNetEvent("fpt-marijuana:client:addGroup")
AddEventHandler("fpt-marijuana:client:addGroup", function()
    jobMarijuanaS.setJob{true}
end)

RegisterNetEvent("fpt-marijuana:client:removeGroup")
AddEventHandler("fpt-marijuana:client:removeGroup", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Pacat... Sa inteleg ca nu iti plac banii?', 7500, 'Grasu')
    jobMarijuanaS.setJob{false}
end)

local plante = {
-- ========================================================================================= --
	-- PLANTATIA 1
    [1] = {
        coords = vector3(5386.1108398438,-5295.1752929688,35.918670654297),
        harvested = false
    },
    
	[2] = {
        coords = vector3(5380.0649414062,-5290.3715820312,35.634262084961),
        harvested = false
    },
	[3] = {
        coords = vector3(5375.23046875,-5286.505859375,35.317291259766),
        harvested = false
    },
	[4] = {
        coords = vector3(5367.236328125,-5280.5327148438,34.641361236572),
        harvested = false
    },
	[5] = {
        coords = vector3(5389.0043945312,-5293.1157226562,35.972526550293),
        harvested = false
    },
	[6] = {
        coords = vector3(5387.2680664062,-5291.7241210938,35.93185043335),
        harvested = false
    },
	[7] = {
        coords = vector3(5385.7719726562,-5290.4365234375,35.88814163208),
        harvested = false
    },
	[8] = {
        coords = vector3(5380.7583007812,-5286.5991210938,35.613231658936),
        harvested = false
    },
	[9] = {
        coords = vector3(5379.859375,-5285.8569335938,35.545700073242),
        harvested = false
    },
	[10] = {
        coords = vector3(5372.185546875,-5280.4311523438,35.028602600098),
        harvested = false
    },
	[11] = {
        coords = vector3(5365.7133789062,-5275.3452148438,34.420349121094),
        harvested = false
    },
	[12] = {
        coords = vector3(5356.3764648438,-5268.3701171875,33.678276062012),
        harvested = false
    },
	-- Randu 2
	[13] = {
        coords = vector3(5351.515625,-5264.64453125,33.416320800781),
        harvested = false
    },
	[14] = {
        coords = vector3(5346.71484375,-5260.8266601562,33.26587677002),
        harvested = false
    },
	[15] = {
        coords = vector3(5344.8540039062,-5259.162109375,33.162330627441),
        harvested = false
    },
	[16] = {
        coords = vector3(5340.6103515625,-5255.8388671875,32.873115539551),
        harvested = false
    },
	[17] = {
        coords = vector3(5335.6411132812,-5252.0263671875,32.705947875977),
        harvested = false
    },
	[18] = {
        coords = vector3(5337.724609375,-5249.38671875,32.536315917969),
        harvested = false
    },
	[19] = {
        coords = vector3(5339.5185546875,-5250.779296875,32.528026580811),
        harvested = false
    },
	[20] = {
        coords = vector3(5344.4458007812,-5254.6586914062,32.797634124756),
        harvested = false
    },
	[21] = {
        coords = vector3(5349.1572265625,-5258.505859375,33.122566223145),
        harvested = false
    },
	[22] = {
        coords = vector3(5356.5825195312,-5264.6000976562,33.387298583984),
        harvested = false
    },
	[23] = {
        coords = vector3(5358.1298828125,-5265.6469726562,33.506401062012),
        harvested = false
    },
    [24] = {
        coords = vector3(5364.7084960938,-5270.90234375,34.078441619873),
        harvested = false
    },
	-- Randu 3
	[25] = {
        coords = vector3(5372.0034179688,-5276.611328125,34.582515716553),
        harvested = false
    },
	[26] = {
        coords = vector3(5373.3408203125,-5277.4243164062,34.682567596436),
        harvested = false
    },
	[27] = {
        coords = vector3(5378.0927734375,-5281.271484375,35.120037078857),
        harvested = false
    },
	[28] = {
        coords = vector3(5379.123046875,-5282.1630859375,35.205936431885),
        harvested = false
    },
	[29] = {
        coords = vector3(5389.3442382812,-5289.7822265625,35.87423324585),
        harvested = false
    },
	[30]= {
        coords = vector3(5391.1572265625,-5290.89453125,35.90678024292),
        harvested = false
    },
	[31] = {
        coords = vector3(5385.2177734375,-5282.6762695312,35.485523223877),
        harvested = false
    },
	[32] = {
        coords = vector3(5380.5126953125,-5279.0732421875,35.198112487793),
        harvested = false
    },
	[33] = {
        coords = vector3(5372.8798828125,-5273.1879882812,34.510620117188),
        harvested = false
    },
	[34] = {
        coords = vector3(5367.9208984375,-5269.4794921875,34.134922027588),
        harvested = false
    },
	[35] = {
        coords = vector3(5366.751953125,-5268.4555664062,34.043590545654),
        harvested = false
    },
	[36] = {
        coords = vector3(5361.0712890625,-5264.1240234375,33.501411437988),
        harvested = false
    },
	-- Randu 4
	[37] = {
        coords = vector3(5355.7275390625,-5259.3784179688,33.204086303711),
        harvested = false
    },
	[38] = {
        coords = vector3(5350.255859375,-5255.087890625,32.996711730957),
        harvested = false
    },
	[39] = {
        coords = vector3(5349.212890625,-5254.341796875,32.9270362854),
        harvested = false
    },
	[40] = {
        coords = vector3(5344.546875,-5250.30078125,32.608737945557),
        harvested = false
    },
	[41] = {
        coords = vector3(5341.43359375,-5248.2666015625,32.553112030029),
        harvested = false
    },
	[42] = {
        coords = vector3(5346.1235351562,-5248.8564453125,32.44660949707),
        harvested = false
    },
	[43] = {
        coords = vector3(5356.36328125,-5256.8725585938,33.007461547852),
        harvested = false
    },
	[44] = {
        coords = vector3(5361.2670898438,-5260.7392578125,33.221782684326),
        harvested = false
    },
	[45] = {
        coords = vector3(5362.4619140625,-5261.556640625,33.32808303833),
        harvested = false
    },
	[46] = {
        coords = vector3(5367.7475585938,-5265.19921875,33.89807510376),
        harvested = false
    },
	[47] = {
        coords = vector3(5373.087890625,-5268.8032226562,34.245899200439),
        harvested = false
    },
    [48] = {
        coords = vector3(5383.14453125,-5276.5405273438,35.093181610107),
        harvested = false
    },
	-- Randu 5
	[49] = {
        coords = vector3(5384.2158203125,-5277.3271484375,35.203857421875),
        harvested = false
    },
	[50] = {
        coords = vector3(5385.3491210938,-5278.2060546875,35.300476074219),
        harvested = false
    },
	[51] = {
        coords = vector3(5386.4375,-5279.0581054688,35.37914276123),
        harvested = false
    },
	[52] = {
        coords = vector3(5391.1455078125,-5283.017578125,35.756278991699),
        harvested = false
    },
	[53] = {
        coords = vector3(5391.8203125,-5283.6416015625,35.784336090088),
        harvested = false
    },
	[54] = {
        coords = vector3(5394.5556640625,-5285.6513671875,35.903072357178),
        harvested = false
    },
	[55] = {
        coords = vector3(5396.92578125,-5283.3598632812,35.863250732422),
        harvested = false
    },
	[56] = {
        coords = vector3(5392.1166992188,-5279.6440429688,35.539249420166),
        harvested = false
    },
	[57] = {
        coords = vector3(5390.6635742188,-5278.2841796875,35.413375854492),
        harvested = false
    },
	[58] = {
        coords = vector3(5384.6372070312,-5273.6860351562,34.977054595947),
        harvested = false
    },
	[59] = {
        coords = vector3(5383.4609375,-5272.7690429688,34.871055603027),
        harvested = false
    },
	[60] = {
        coords = vector3(5372.2182617188,-5263.7006835938,33.953197479248),
        harvested = false
    },
	-- Randu 6
	[61] = {
        coords = vector3(5371.0883789062,-5262.96875,33.888298034668),
        harvested = false
    },
	[62] = {
        coords = vector3(5366.2758789062,-5259.328125,33.410457611084),
        harvested = false
    },
	[63] = {
        coords = vector3(5351.9956054688,-5248.4365234375,32.698490142822),
        harvested = false
    },
	[64] = {
        coords = vector3(5346.8408203125,-5244.3369140625,32.447120666504),
        harvested = false
    },
	[65] = {
        coords = vector3(5341.951171875,-5240.65234375,32.201015472412),
        harvested = false
    },
	[66] = {
        coords = vector3(5344.0639648438,-5237.767578125,32.127185821533),
        harvested = false
    },
	[67] = {
        coords = vector3(5346.0659179688,-5239.236328125,32.302295684814),
        harvested = false
    },
	[68] = {
        coords = vector3(5347.5493164062,-5240.3569335938,32.438259124756),
        harvested = false
    },
	[69] = {
        coords = vector3(5348.68359375,-5241.2172851562,32.462707519531),
        harvested = false
    },
	[70] = {
        coords = vector3(5353.2373046875,-5245.11328125,32.659229278564),
        harvested = false
    },
	[71] = {
        coords = vector3(5354.5078125,-5246.27734375,32.730880737305),
        harvested = false
    },
    [72] = {
        coords = vector3(5359.748046875,-5250.4721679688,32.944869995117),
        harvested = false
    },
	-- Randu 7
	[73] = {
        coords = vector3(5364.4765625,-5254.0932617188,33.196258544922),
        harvested = false
    },
	[74] = {
        coords = vector3(5374.013671875,-5261.4877929688,33.995529174805),
        harvested = false
    },
	[75] = {
        coords = vector3(5375.0483398438,-5262.2724609375,34.040981292725),
        harvested = false
    },
	[76] = {
        coords = vector3(5376.4487304688,-5263.1733398438,34.096927642822),
        harvested = false
    },
	[77] = {
        coords = vector3(5381.3251953125,-5267.0771484375,34.581336975098),
        harvested = false
    },
	[78] = {
        coords = vector3(5386.1059570312,-5271.1435546875,34.972946166992),
        harvested = false
    },
	[79] = {
        coords = vector3(5387.2412109375,-5271.7939453125,35.075565338135),
        harvested = false
    },
	[80] = {
        coords = vector3(5388.6103515625,-5272.65625,35.153987884521),
        harvested = false
    },
	[81] = {
        coords = vector3(5389.5415039062,-5273.3779296875,35.215049743652),
        harvested = false
    },
	[82] = {
        coords = vector3(5394.4130859375,-5277.1279296875,35.704620361328),
        harvested = false
    },
	[83] = {
        coords = vector3(5399.208984375,-5280.888671875,36.011264801025),
        harvested = false
    },
	[84] = {
        coords = vector3(5400.1044921875,-5277.5180664062,36.010643005371),
        harvested = false
    },
	-- Randu 8
	[85] = {
        coords = vector3(5387.1298828125,-5268.3696289062,34.837669372559),
        harvested = false
    },
	[86] = {
        coords = vector3(5385.8344726562,-5267.421875,34.74153137207),
        harvested = false
    },
	[87] = {
        coords = vector3(5381.24609375,-5263.4702148438,34.389736175537),
        harvested = false
    },
	[88] = {
        coords = vector3(5378.365234375,-5261.5620117188,34.052570343018),
        harvested = false
    },
	[89] = {
        coords = vector3(5373.5654296875,-5257.81640625,33.778743743896),
        harvested = false
    },
	[90] = {
        coords = vector3(5367.5415039062,-5253.1782226562,33.234580993652),
        harvested = false
    },
	[91] = {
        coords = vector3(5362.775390625,-5249.1674804688,33.005920410156),
        harvested = false
    },
	[92] = {
        coords = vector3(5360.7021484375,-5248.03125,32.830951690674),
        harvested = false
    },
	[93] = {
        coords = vector3(5361.2651367188,-5243.5756835938,32.795150756836),
        harvested = false
    },
	[94] = {
        coords = vector3(5375.7436523438,-5255.1655273438,33.741542816162),
        harvested = false
    },
	[95] = {
        coords = vector3(5380.85546875,-5259.3466796875,34.112087249756),
        harvested = false
    },
    [96] = {
        coords = vector3(5381.9296875,-5260.1723632812,34.202587127686),
        harvested = false
    },
	-- Randu 9
	[97] = {
        coords = vector3(5386.6274414062,-5263.6948242188,34.607173919678),
        harvested = false
    },
	[98] = {
        coords = vector3(5387.7348632812,-5264.4453125,34.711959838867),
        harvested = false
    },
	[99] = {
        coords = vector3(5392.3388671875,-5268.2124023438,35.078708648682),
        harvested = false
    },
	[100] = {
        coords = vector3(5397.2236328125,-5272.0458984375,35.504505157471),
        harvested = false
    },
	[101] = {
        coords = vector3(5399.5434570312,-5269.3198242188,35.749877929688),
        harvested = false
    },
	[102] = {
        coords = vector3(5394.7358398438,-5265.4990234375,35.262012481689),
        harvested = false
    },
	[103] = {
        coords = vector3(5393.611328125,-5264.6767578125,35.180202484131),
        harvested = false
    },
	[104] = {
        coords = vector3(5388.673828125,-5260.9912109375,34.728088378906),
        harvested = false
    },
	[105] = {
        coords = vector3(5387.3051757812,-5259.99609375,34.603122711182),
        harvested = false
    },
	[106] = {
        coords = vector3(5375.8764648438,-5251.55078125,33.615886688232),
        harvested = false
    },
	[107] = {
        coords = vector3(5369.5776367188,-5246.482421875,33.080196380615),
        harvested = false
    },
	[108] = {
        coords = vector3(5364.708984375,-5242.5249023438,32.857757568359),
        harvested = false
    },
	-- Randu 10
	[109] = {
        coords = vector3(5362.8471679688,-5241.2109375,32.792087554932),
        harvested = false
    },
	[110] = {
        coords = vector3(5361.810546875,-5240.4428710938,32.713405609131),
        harvested = false
    },
	[111] = {
        coords = vector3(5355.05078125,-5234.4438476562,32.366756439209),
        harvested = false
    },
	[112] = {
        coords = vector3(5354.5380859375,-5229.7177734375,31.991153717041),
        harvested = false
    },
	[113] = {
        coords = vector3(5356.1196289062,-5231.2255859375,32.161468505859),
        harvested = false
    },
	[114] = {
        coords = vector3(5360.9760742188,-5235.2890625,32.42484664917),
        harvested = false
    },
	[115] = {
        coords = vector3(5365.8247070312,-5239.1962890625,32.850769042969),
        harvested = false
    },
	[116] = {
        coords = vector3(5371.1850585938,-5243.615234375,33.056575775146),
        harvested = false
    },
	[117] = {
        coords = vector3(5373.1997070312,-5245.1845703125,33.234718322754),
        harvested = false
    },
	[118] = {
        coords = vector3(5374.4340820312,-5245.9448242188,33.384410858154),
        harvested = false
    },
	[119] = {
        coords = vector3(5381.4038085938,-5251.3330078125,33.967765808105),
        harvested = false
    },
    [120] = {
        coords = vector3(5386.8896484375,-5255.7963867188,34.408908843994),
        harvested = false
    },
	-- Randu 11
	[121] = {
        coords = vector3(5388.7470703125,-5257.0400390625,34.617069244385),
        harvested = false
    },
	[122] = {
        coords = vector3(5390.0966796875,-5257.8720703125,34.768230438232),
        harvested = false
    },
	[123] = {
        coords = vector3(5394.8940429688,-5261.71875,35.119834899902),
        harvested = false
    },
	[124] = {
        coords = vector3(5395.9047851562,-5262.3813476562,35.229068756104),
        harvested = false
    },
	[125] = {
        coords = vector3(5401.3666992188,-5266.626953125,35.733909606934),
        harvested = false
    },
	[126] = {
        coords = vector3(5406.0385742188,-5270.0336914062,36.153087615967),
        harvested = false
    },
	[127] = {
        coords = vector3(5404.0581054688,-5264.30859375,35.760635375977),
        harvested = false
    },
	[128] = {
        coords = vector3(5401.7983398438,-5262.6455078125,35.532028198242),
        harvested = false
    },
	[129] = {
        coords = vector3(5400.7802734375,-5261.7426757812,35.443874359131),
        harvested = false
    },
	[130] = {
        coords = vector3(5390.5375976562,-5254.1245117188,34.531314849854),
        harvested = false
    },
	[131] = {
        coords = vector3(5385.9340820312,-5250.3208007812,34.13236618042),
        harvested = false
    },
	[132] = {
        coords = vector3(5381.1567382812,-5246.6005859375,33.764133453369),
        harvested = false
    },
	-- Randu 12
	[133] = {
        coords = vector3(5379.7705078125,-5245.6811523438,33.620422363281),
        harvested = false
    },
	[134] = {
        coords = vector3(5374.978515625,-5241.9775390625,33.187183380127),
        harvested = false
    },
	[135] = {
        coords = vector3(5374.0522460938,-5241.2373046875,33.113300323486),
        harvested = false
    },
	[136] = {
        coords = vector3(5364.05078125,-5233.4458007812,32.362503051758),
        harvested = false
    },
	[137] = {
        coords = vector3(5358.0859375,-5224.9326171875,31.706108093262),
        harvested = false
    },
	[138] = {
        coords = vector3(5362.8046875,-5228.6723632812,32.034488677979),
        harvested = false
    },
	[139] = {
        coords = vector3(5363.9091796875,-5229.3530273438,32.116397857666),
        harvested = false
    },
	[140] = {
        coords = vector3(5369.26953125,-5233.8481445312,32.611724853516),
        harvested = false
    },
	[141] = {
        coords = vector3(5374.6025390625,-5238.1484375,33.016639709473),
        harvested = false
    },
	[142] = {
        coords = vector3(5376.4135742188,-5239.4711914062,33.174758911133),
        harvested = false
    },
	[143] = {
        coords = vector3(5381.1479492188,-5243.0029296875,33.637672424316),
        harvested = false
    },
    [144] = {
        coords = vector3(5382.2329101562,-5243.6201171875,33.805595397949),
        harvested = false
    },
    [145] = {
        coords = vector3(5384.1748046875,-5245.0302734375,33.912132263184),
        harvested = false
    },
    [146] = {
        coords = vector3(5388.8872070312,-5248.9194335938,34.214138031006),
        harvested = false
    },
    [147] = {
        coords = vector3(5390.8916015625,-5250.509765625,34.430660247803),
        harvested = false
    },
    [148] = {
        coords = vector3(5406.4907226562,-5258.7705078125,35.708713531494),
        harvested = false
    },
    [149] = {
        coords = vector3(5401.6962890625,-5254.9301757812,35.265880584717),
        harvested = false
    },
    [150] = {
        coords = vector3(5396.228515625,-5250.1342773438,34.836162567139),
        harvested = false
    },
    [151] = {
        coords = vector3(5393.34765625,-5248.1298828125,34.544376373291),
        harvested = false
    },
    [152] = {
        coords = vector3(5388.6049804688,-5244.373046875,34.140888214111),
        harvested = false
    },
    [153] = {
        coords = vector3(5382.5634765625,-5239.83203125,33.593925476074),
        harvested = false
    },
    [154] = {
        coords = vector3(5377.1381835938,-5235.7260742188,33.067325592041),
        harvested = false
    },
    [155] = {
        coords = vector3(5375.5576171875,-5234.7978515625,32.917713165283),
        harvested = false
    },
    [156] = {
        coords = vector3(5360.8540039062,-5222.7592773438,31.56756401062),
        harvested = false
    },
    [157] = {
        coords = vector3(5366.5014648438,-5222.9370117188,31.71417427063),
        harvested = false
    },
    [158] = {
        coords = vector3(5371.3427734375,-5226.5400390625,32.187831878662),
        harvested = false
    },
    [159] = {
        coords = vector3(5376.0620117188,-5230.1372070312,32.724319458008),
        harvested = false
    },
    [160] = {
        coords = vector3(5380.70703125,-5233.904296875,33.173709869385),
        harvested = false
    },
    [161] = {
        coords = vector3(5381.9487304688,-5234.6713867188,33.243434906006),
        harvested = false
    },
    [162] = {
        coords = vector3(5383.2866210938,-5235.646484375,33.382785797119),
        harvested = false
    },
    [163] = {
        coords = vector3(5388.2797851562,-5239.6328125,33.90393447876),
        harvested = false
    },
    [164] = {
        coords = vector3(5394.0864257812,-5244.3974609375,34.35001373291),
        harvested = false
    },
    [165] = {
        coords = vector3(5395.1484375,-5245.228515625,34.453784942627),
        harvested = false
    },
    [166] = {
        coords = vector3(5396.583984375,-5246.2890625,34.591133117676),
        harvested = false
    },
    [167] = {
        coords = vector3(5401.5180664062,-5250.1806640625,35.059379577637),
        harvested = false
    },
    [168] = {
        coords = vector3(5406.3564453125,-5253.869140625,35.469627380371),
        harvested = false
    },
    [169] = {
        coords = vector3(5411.8540039062,-5258.146484375,36.05347442627),
        harvested = false
    },
    [170] = {
        coords = vector3(5412.2631835938,-5254.6127929688,35.985229492188),
        harvested = false
    },
    [171] = {
        coords = vector3(5407.7114257812,-5250.705078125,35.505584716797),
        harvested = false
    },
    [172] = {
        coords = vector3(5402.8359375,-5246.9682617188,35.05931854248),
        harvested = false
    },
    [173] = {
        coords = vector3(5401.251953125,-5245.890625,34.91361618042),
        harvested = false
    },
    [174] = {
        coords = vector3(5398.0434570312,-5243.8408203125,34.616321563721),
        harvested = false
    },
    [175] = {
        coords = vector3(5397.1533203125,-5243.2177734375,34.492740631104),
        harvested = false
    },
    [176] = {
        coords = vector3(5391.4624023438,-5238.8505859375,34.011196136475),
        harvested = false
    },
    [177] = {
        coords = vector3(5385.314453125,-5234.1079101562,33.401271820068),
        harvested = false
    },
    [178] = {
        coords = vector3(5374.1176757812,-5225.5043945312,32.314262390137),
        harvested = false
    },
    [179] = {
        coords = vector3(5364.7202148438,-5217.9409179688,31.368021011353),
        harvested = false
    },
    [180] = {
        coords = vector3(5380.3598632812,-5225.6704101562,32.892631530762),
        harvested = false
    },
    [181] = {
        coords = vector3(5394.2778320312,-5236.7084960938,34.128360748291),
        harvested = false
    },
    [182] = {
        coords = vector3(5399.9077148438,-5241.3100585938,34.602993011475),
        harvested = false
    },
    [183] = {
        coords = vector3(5400.9458007812,-5242.017578125,34.734565734863),
        harvested = false
    },
    [184] = {
        coords = vector3(5405.9780273438,-5245.5361328125,35.16104888916),
        harvested = false
    },
    [185] = {
        coords = vector3(5411.6044921875,-5250.0083007812,35.735046386719),
        harvested = false
    },
-- ======================================================================================= --
    -- Plantatia 2
    [186] = {
        coords = vector3(5222.0805664062,-5171.2919921875,12.019560813904),
        harvested = false
    },
    [187] = {
        coords = vector3(5221.994140625,-5168.9453125,11.915139198303),
        harvested = false
    },
    [188] = {
        coords = vector3(5222.4453125,-5165.58203125,11.87163734436),
        harvested = false
    },
    [189] = {
        coords = vector3(5223.0126953125,-5159.126953125,11.57807636261),
        harvested = false
    },
    [190] = {
        coords = vector3(5221.1474609375,-5142.8193359375,9.8051986694336),
        harvested = false
    },
    [191] = {
        coords = vector3(5221.0327148438,-5144.416015625,10.148449897766),
        harvested = false
    },
    [192] = {
        coords = vector3(5220.1557617188,-5158.1147460938,11.464698791504),
        harvested = false
    },
    [193] = {
        coords = vector3(5220.01171875,-5159.552734375,11.564985275269),
        harvested = false
    },
    [194] = {
        coords = vector3(5220.0141601562,-5169.74609375,11.955496788025),
        harvested = false
    },
    [195] = {
        coords = vector3(5219.9697265625,-5171.150390625,12.053030014038),
        harvested = false
    },
    [196] = {
        coords = vector3(5219.8481445312,-5179.6538085938,12.783122062683),
        harvested = false
    },
    [197] = {
        coords = vector3(5216.21484375,-5183.5493164062,13.298052787781),
        harvested = false
    },
    [198] = {
        coords = vector3(5216.4838867188,-5162.9672851562,11.601167678833),
        harvested = false
    },
    [199] = {
        coords = vector3(5216.5805664062,-5161.6860351562,11.466881752014),
        harvested = false
    },
    [200] = {
        coords = vector3(5216.8466796875,-5160.3666992188,11.385065078735),
        harvested = false
    },
    [201] = {
        coords = vector3(5217.5043945312,-5152.9448242188,10.557091712952),
        harvested = false
    },
    [202] = {
        coords = vector3(5218.421875,-5138.478515625,8.9199895858765),
        harvested = false
    },
    [203] = {
        coords = vector3(5214.6923828125,-5153.1284179688,10.04861831665),
        harvested = false
    },
    [204] = {
        coords = vector3(5214.3715820312,-5154.5004882812,10.117588043213),
        harvested = false
    },
    [205] = {
        coords = vector3(5213.8696289062,-5160.2661132812,10.896673202515),
        harvested = false
    },
    [206] = {
        coords = vector3(5213.1997070312,-5172.69921875,12.29400062561),
        harvested = false
    },
    [207] = {
        coords = vector3(5213.068359375,-5178.8803710938,12.696531295776),
        harvested = false
    },
    [208] = {
        coords = vector3(5213.052734375,-5186.1000976562,13.422249794006),
        harvested = false
    },
    [209] = {
        coords = vector3(5209.7001953125,-5187.4116210938,13.418517112732),
        harvested = false
    },
    [210] = {
        coords = vector3(5210.0297851562,-5181.5278320312,12.803198814392),
        harvested = false
    },
    [211] = {
        coords = vector3(5210.0615234375,-5178.755859375,12.601683616638),
        harvested = false
    },
    [212] = {
        coords = vector3(5210.373046875,-5172.748046875,12.276929855347),
        harvested = false
    },
    [213] = {
        coords = vector3(5210.6943359375,-5161.0966796875,10.763883590698),
        harvested = false
    },
    [214] = {
        coords = vector3(5211.0205078125,-5158.2119140625,10.237197875977),
        harvested = false
    },
    [215] = {
        coords = vector3(5208.1513671875,-5155.7573242188,9.4029684066772),
        harvested = false
    },
    [216] = {
        coords = vector3(5207.8442382812,-5166.962890625,11.580990791321),
        harvested = false
    },
    [217] = {
        coords = vector3(5206.7241210938,-5181.6547851562,12.462828636169),
        harvested = false
    },
    [218] = {
        coords = vector3(5206.2456054688,-5189.1752929688,13.153498649597),
        harvested = false
    },
    [219] = {
        coords = vector3(5205.1337890625,-5158.8681640625,9.5877647399902),
        harvested = false
    },
    [220] = {
        coords = vector3(5205.4497070312,-5156.7270507812,9.1761054992676),
        harvested = false
    },
    [221] = {
        coords = vector3(5201.5415039062,-5163.9716796875,9.9563188552856),
        harvested = false
    },
    [222] = {
        coords = vector3(5200.9985351562,-5171.6157226562,10.590614318848),
        harvested = false
    },
    [223] = {
        coords = vector3(5200.1982421875,-5189.6733398438,11.998970985413),
        harvested = false
    },
    [224] = {
        coords = vector3(5196.8813476562,-5190.9135742188,11.431813240051),
        harvested = false
    },
    [225] = {
        coords = vector3(5197.498046875,-5183.6323242188,10.855234146118),
        harvested = false
    },
    [226] = {
        coords = vector3(5198.1049804688,-5176.5854492188,10.374978065491),
        harvested = false
    },
    [227] = {
        coords = vector3(5198.5400390625,-5167.4692382812,9.61803150177),
        harvested = false
    },
    [228] = {
        coords = vector3(5195.7099609375,-5163.9296875,8.7573204040527),
        harvested = false
    },
    [229] = {
        coords = vector3(5195.4301757812,-5165.5791015625,8.8769102096558),
        harvested = false
    },
    [230] = {
        coords = vector3(5195.0620117188,-5171.6733398438,9.4284009933472),
        harvested = false
    },
    [231] = {
        coords = vector3(5194.8950195312,-5173.8481445312,9.5662336349487),
        harvested = false
    },
    [232] = {
        coords = vector3(5194.6762695312,-5179.861328125,10.110368728638),
        harvested = false
    },
    [233] = {
        coords = vector3(5194.033203125,-5189.6547851562,10.794861793518),
        harvested = false
    },
    [234] = {
        coords = vector3(5194.0483398438,-5191.3486328125,10.952865600586),
        harvested = false
    },
}

local mese = {
    [1] = {
        coords = vector3(5127.5297851562,-5181.4150390625,-4.6696934700012),
        heading = 359.00311279297,
        offsetX = 0.20,
        offsetY = 0.60,
        offsetZ = - 1.02,
        loc = 1,
        rot = 0.0
    },
    [2] = {
        coords = vector3(5129.9443359375,-5181.4125976562,-4.6696934700012),
        heading = 359.00311279297,
        offsetX = 0.20,
        offsetY = 0.60,
        offsetZ = - 1.02,
        loc = 2,
        rot = 0.0
    },
    [3] = {
        coords = vector3(5133.0380859375,-5181.4125976562,-4.6696934700012),
        heading = 359.003112792971,
        offsetX = 0.20,
        offsetY = 0.60,
        offsetZ = - 1.02,
        loc = 3,
        rot = 0.0
    },
    [4] = {
        coords = vector3(5135.7373046875,-5181.4130859375,-4.6696934700012),
        heading = 359.00311279297,
        offsetX = 0.20,
        offsetY = 0.60,
        offsetZ = - 1.02,
        loc = 4,
        rot = 0.0
    }
}

local scaune = { 
    [1] = {
        coords = vector3(5127.615234375,-5181.5732421875,-5.7275609970093),
        rot = 180.0
    },
    [2] = {
        coords = vector3(5130.0297851562,-5181.5708007812,-5.7275609970093),
        rot = 180.0
    },
    [3] = {
        coords = vector3(5133.1235351562,-5181.5708007812,-5.7275609970093),
        rot = 180.0
    },
    [4] = {
        coords = vector3(5135.8227539062,-5181.5712890625,-5.7275609970093),
        rot = 180.0
    }
}

local showedScaune = {}

scaune[1].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[1].coords.x, scaune[1].coords.y, scaune[1].coords.z , false, false, false)
scaune[2].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[2].coords.x, scaune[2].coords.y, scaune[2].coords.z , false, false, false)
scaune[3].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[3].coords.x, scaune[3].coords.y, scaune[3].coords.z , false, false, false)
scaune[4].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[4].coords.x, scaune[4].coords.y, scaune[4].coords.z , false, false, false)
SetEntityRotation(scaune[1].obj, 0.0, 0.0, scaune[1].rot)
SetEntityRotation(scaune[2].obj, 0.0, 0.0, scaune[2].rot)
SetEntityRotation(scaune[3].obj, 0.0, 0.0, scaune[3].rot)
SetEntityRotation(scaune[4].obj, 0.0, 0.0, scaune[4].rot)

local showedPlante = {}
local spawnedPlants = {}

for k,v in pairs(plante) do
    showedPlante[k] = false
end

for k,v in pairs(plante) do
    spawnedPlants[k] = {}
    spawnedPlants[k].spawned = false
    spawnedPlants[k].obj = nil
end

RegisterNetEvent("syncplant1")
AddEventHandler("syncplant1", function(plantid, ft)
    print("aaaa123")
    spawnedPlants[plantid].harvested = ft
    spawnedPlants[plantid].spawned = ft
    DeleteEntity(spawnedPlants[plantid].obj)
end)

local infoliatProcess = {
    coords = vector3(5196.1484375,-5133.6196289063,3.359459400177),
    heading = 357.35235595703
}

CreateThread(function()
    while true do
        Citizen.Wait(200)
        if canDoJob then
            Citizen.Wait(2000)
            local coordonate = vector3(5327.9106445312,-5195.140625,31.93155670166)
            local distanta = getPlayerPosition(coordonate)
            if distanta < 100 then
                
                    for k,v in pairs(plante or {}) do
                        if not plante[k].harvested and not spawnedPlants[k].spawned then
                            spawnedPlants[k].obj = CreateObject(GetHashKey('prop_weed_01'), v.coords.x, v.coords.y, v.coords.z - 1, false, false, false)
                            SetEntityAsMissionEntity(spawnedPlants[k].obj, false, false)
                            FreezeEntityPosition(spawnedPlants[k].obj, true)
                            spawnedPlants[k].spawned = true
                        else
                            if plante[k].harvested and spawnedPlants[k].spawned then
                                DeleteEntity(spawnedPlants[k].obj)
                                spawnedPlants[k].obj = nil
                                spawnedPlants[k].spawned = false
                            end
                        end
                    end
              
            end
        end
    end
end)

local inRange = false
local notified = false

CreateThread(function()
    while true do
        Citizen.Wait(0)
        if canDoJob then
            inRange = false

            for k,v in pairs(plante) do
                if v.harvested == false then
                    dist = getPlayerPosition(v.coords)
                    if dist < 1 then
                        local obj = GetClosestObjectOfType(pos.x, pos.y, pos.z, 1, GetHashKey('prop_weed_01'), false)
                        if not showedPlante[k] and obj then
                            exports['fpt-textui']:Open('[E] Culege Marijuana', 'darkblue', 'left')
                            showedPlante[k] = true
                        end
                        inRange = true
                        if IsControlJustPressed(0,38) then
                            jobMarijuanaF:colecteazaPlanta(k)
                            exports['fpt-textui']:Close()
                        end
                    else
                        if showedPlante[k] then
                            exports['fpt-textui']:Close()
                            showedPlante[k] = false
                        end
                    end
                end
            end

            local distance2 = getPlayerPosition(infoliatProcess.coords)

            if distance2 < 1.5 then
                inRange = true
                DrawMarker(27, vector3(infoliatProcess.coords.x,infoliatProcess.coords.y,infoliatProcess.coords.z - 0.99), 0,0,0,0,0,0,0.5,0.5,0.2,255,255,255,100,0,0,0,0)
                if not notified then
                    notified = true
                    exports['fpt-textui']:Open('[E] Infoliaza Marijuana', 'darkblue', 'left')
                end
                if IsControlJustPressed(0,38) then
                    exports['fpt-textui']:Close()
                    jobMarijuanaF:infoliazaMarijuana()
                end
            end

            for k,v in pairs(mese) do 
                local dst = getPlayerPosition(mese[k].coords)
                if dst < 1.5 then
                    inRange = true
                    if not notified then
                        notified = true
                        exports['fpt-textui']:Open('[E] Proceseaza Marijuana', 'darkblue', 'left')
                    end
                    DrawMarker(27, vector3(mese[k].coords.x,mese[k].coords.y,mese[k].coords.z - 1.0), 0,0,0,0,0,0,0.5,0.5,0.2,255,255,255,100,0,0,0,0)
                    if IsControlJustPressed(0, 38) then
                        
                                exports['fpt-textui']:Close()
                                jobMarijuanaS.hasItems({"marijuana", 1}, function (has)
                                    if has then
                                        jobMarijuanaS.takeItems{"marijuana", 1}
                                        jobMarijuanaF:proceseazaMarijuana(mese[k].coords, mese[k].heading, mese[k].loc, mese[k].offsetX, mese[k].offsetY, mese[k].offsetZ, mese[k].rot)
                                    else    
                                        jobMarijuanaS.eliberatMasa{mese[k].loc}
                                        TriggerEvent("fplaytbank:notifications", "error", "Ai nevoie de planta de marijuana!", 7500, "FPlayT")
                                    end
                                end)
          
                        
                    end
                end
            end

            if not hasJob then
                jobMarijuanaF:setUpJob()
            else
                local distLivrare = getPlayerPosition(position)
                if distLivrare < 10 then
                    inRange = true
                    DrawMarker(20,position.x,position.y,position.z + 0.1,0,0,0,0,0,0,0.35,0.35,-0.60,230,0,0,85,0)
                end
                if distLivrare < 1.5 then
                    inRange = true
                    if not showedLivrare then
                        exports['fpt-textui']:Open('[E] Bate la usa', 'darkblue', 'left')
                        showedLivrare = true
                    end
                    if IsControlJustPressed(0,38) then
                        jobMarijuanaF:livreaza()
                        exports['fpt-textui']:Close()
                    end
                else
                    if showedLivrare then
                        exports['fpt-textui']:Close()
                        showedLivrare = false
                    end
                end
            end
     
            if not inRange then
                Citizen.Wait(1000)
                if notified then
                    notified = false
                    exports['fpt-textui']:Close()
                end
            end
        else
            Citizen.Wait(1000)
        end
    end
end)

function jobMarijuanaF:setUpJob()
    hasJob = true
    if blip then
        RemoveBlip(blip)
    end
    local x,y,z = table.unpack(coordsLivrare[math.random(1,#coordsLivrare)])
    position = vector3(x,y,z)
    blip = AddBlipForCoord(position.x,position.y,position.z)
	SetBlipAsShortRange(blip, true)
	SetBlipRoute(blip, true)
	SetBlipScale(blip, 0.6)
	SetBlipSprite(blip, 501)
	SetBlipColour(blip, 25)
	SetBlipRouteColour(blip, 25)
    pachete = math.random(2,4)
    strada = GetStreetNameAtCoord(position.x, position.y, position.z, Citizen.ResultAsInteger(), Citizen.ResultAsInteger())
    numeStrada = GetStreetNameFromHashKey(strada)
    jobMarijuanaS.trimiteMail{numeStrada, pachete}
end

function jobMarijuanaF:livreaza()
    jobMarijuanaS.hasItems({"marijuana10g", pachete}, function (has)
        if has then
            exports['progressBars']:startUI(15000, "Livrezi...")
            local hash = GetHashKey("bkr_prop_weed_bag_01a")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(100)
                RequestModel(hash)
            end
            TaskPlayAnim("timetable@jimmy@doorknock@", "knockdoor_idle", 2.0, 2.0, 5000, 51, 0, false, false, false)
            Citizen.Wait(5000)
            TaskPlayAnim("anim@mugging@victim@toss_ped@", "throw_object_right_pocket_male", 2.0, 2.0, 2000, 51, 0, false, false, false)
            Citizen.Wait(300)
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.07, -0.01, -0.04, 0.0, 0.0, 190.0, true, true, false, false, 1, true)
            Citizen.Wait(1700)
            TaskPlayAnim("tunf_iaa_mcs1-1", "mp_m_freemode_01^3_dual-1", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(3000)
            TaskPlayAnim("mp_common", "givetake1_b", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(1500)
            DeleteObject(prop)
            Citizen.Wait(3500)
            
            hasJob = false
            jobMarijuanaS.livreaza{pachete}
            ClearPedTasks(PlayerPedId())    
        else
            TriggerEvent('fplaytbank:notifications', 'error', 'Nu ai marfa la tine!', 7500, 'Client')    
        end
    end)
end

function jobMarijuanaF:proceseazaMarijuana(coord, heading, loc, offsetX, offsetY, offsetZ, rot)
    local animDict = "anim@amb@business@weed@weed_sorting_seated@"
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Citizen.Wait(10) end
    RequestModel("bkr_prop_weed_dry_01a")
    RequestModel("bkr_prop_weed_leaf_01a")
    RequestModel("bkr_prop_weed_bag_01a")
    RequestModel("bkr_prop_weed_bud_02b")
    RequestModel("bkr_prop_weed_bud_02a")
    RequestModel("bkr_prop_weed_bag_pile_01a")
    RequestModel("bkr_prop_weed_bucket_open_01a")
    while not HasModelLoaded("bkr_prop_weed_dry_01a") and not HasModelLoaded("bkr_prop_weed_leaf_01a") and not HasModelLoaded("bkr_prop_weed_bag_01a") and not HasModelLoaded("bkr_prop_weed_bud_02b") and not HasModelLoaded("bkr_prop_weed_bud_02a") and not HasModelLoaded("bkr_prop_weed_bag_pile_01a") and not HasModelLoaded("bkr_prop_weed_bucket_open_01a") do Citizen.Wait(50) end
    SetEntityHeading(PlayerPedId(), heading)
    Citizen.Wait(10)
    local packScene = NetworkCreateSynchronisedScene(coord.x+offsetX, coord.y+offsetY, coord.z+offsetZ, 0.0, 0.0, rot, 2, false, false, 1065353216, 0, 1.3)
    local packScene2 = NetworkCreateSynchronisedScene(coord.x+offsetX, coord.y+offsetY, coord.z+offsetZ, 0.0, 0.0, rot, 2, false, false, 1065353216, 0, 1.3)
    local packScene3 = NetworkCreateSynchronisedScene(coord.x+offsetX, coord.y+offsetY, coord.z+offsetZ, 0.0, 0.0, rot, 2, false, false, 1065353216, 0, 1.3)
    local packScene4 = NetworkCreateSynchronisedScene(coord.x+offsetX, coord.y+offsetY, coord.z+offsetZ, 0.0, 0.0, rot, 2, false, false, 1065353216, 0, 1.3)
    local packScene5 = NetworkCreateSynchronisedScene(coord.x+offsetX, coord.y+offsetY, coord.z+offsetZ, 0.0, 0.0, rot, 2, false, false, 1065353216, 0, 1.3)
    local packScene6 = NetworkCreateSynchronisedScene(coord.x+offsetX, coord.y+offsetY, coord.z+offsetZ, 0.0, 0.0, rot, 2, false, false, 1065353216, 0, 1.3)
    local dry = CreateObject(GetHashKey("bkr_prop_weed_dry_01a"), coord.x, coord.y, coord.z, true, false, false)
    local dry2 = CreateObject(GetHashKey("bkr_prop_weed_dry_01a"), coord.x, coord.y, coord.z, true, false, false)
    local leaf = CreateObject(GetHashKey("bkr_prop_weed_leaf_01a"), coord.x, coord.y, coord.z, true, false, false)
    local leaf2 = CreateObject(GetHashKey("bkr_prop_weed_leaf_01a"), coord.x, coord.y, coord.z, true, false, false)
    local bag = CreateObject(GetHashKey("bkr_prop_weed_bag_01a"), coord.x, coord.y, coord.z, true, false, false)
    local bud = CreateObject(GetHashKey("bkr_prop_weed_bud_02b"), coord.x, coord.y, coord.z, true, false, false)
    local bud2 = CreateObject(GetHashKey("bkr_prop_weed_bud_02b"), coord.x, coord.y, coord.z, true, false, false)
    local bud3 = CreateObject(GetHashKey("bkr_prop_weed_bud_02b"), coord.x, coord.y, coord.z, true, false, false)
    local bud4 = CreateObject(GetHashKey("bkr_prop_weed_bud_02b"), coord.x, coord.y, coord.z, true, false, false)
    local bud5 = CreateObject(GetHashKey("bkr_prop_weed_bud_02b"), coord.x, coord.y, coord.z, true, false, false)
    local bud6 = CreateObject(GetHashKey("bkr_prop_weed_bud_02b"), coord.x, coord.y, coord.z, true, false, false)
    local bud7 = CreateObject(GetHashKey("bkr_prop_weed_bud_02a"), coord.x, coord.y, coord.z, true, false, false)
    local bud8 = CreateObject(GetHashKey("bkr_prop_weed_bud_02a"), coord.x, coord.y, coord.z, true, false, false)
    local bud9 = CreateObject(GetHashKey("bkr_prop_weed_bud_02a"), coord.x, coord.y, coord.z, true, false, false)
    local bag2 = CreateObject(GetHashKey("bkr_prop_weed_bag_pile_01a"), coord.x, coord.y, coord.z, true, false, false)
    local buck = CreateObject(GetHashKey("bkr_prop_weed_bucket_open_01a"), coord.x, coord.y, coord.z, true, false, false)
    local buck2 = CreateObject(GetHashKey("bkr_prop_weed_bucket_open_01a"), coord.x, coord.y, coord.z, true, false, false)
    NetworkAddPedToSynchronisedScene(PlayerPedId(), packScene, animDict, "sorter_right_sort_v3_sorter02", 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(dry, packScene, animDict, "sorter_right_sort_v3_weeddry01a", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(dry2, packScene, animDict, "sorter_right_sort_v3_weeddry01a^1", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(leaf, packScene, animDict, "sorter_right_sort_v3_weedleaf01a", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(leaf2, packScene2, animDict, "sorter_right_sort_v3_weedleaf01a^1", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bag, packScene2, animDict, "sorter_right_sort_v3_weedbag01a", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud, packScene2, animDict, "sorter_right_sort_v3_weedbud02b", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud2, packScene3, animDict, "sorter_right_sort_v3_weedbud02b^1", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud3, packScene3, animDict, "sorter_right_sort_v3_weedbud02b^2", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud4, packScene3, animDict, "sorter_right_sort_v3_weedbud02b^3", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud5, packScene4, animDict, "sorter_right_sort_v3_weedbud02b^4", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud6, packScene4, animDict, "sorter_right_sort_v3_weedbud02b^5", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud7, packScene4, animDict, "sorter_right_sort_v3_weedbud02a", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud8, packScene5, animDict, "sorter_right_sort_v3_weedbud02a^1", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bud9, packScene5, animDict, "sorter_right_sort_v3_weedbud02a^2", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(bag2, packScene5, animDict, "sorter_right_sort_v3_weedbagpile01a", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(buck, packScene6, animDict, "sorter_right_sort_v3_bucket01a", 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(buck2, packScene6, animDict, "sorter_right_sort_v3_bucket01a^1", 4.0, -8.0, 1)
    NetworkStartSynchronisedScene(packScene)
    NetworkStartSynchronisedScene(packScene2)
    NetworkStartSynchronisedScene(packScene3)
    NetworkStartSynchronisedScene(packScene4)
    NetworkStartSynchronisedScene(packScene5)
    NetworkStartSynchronisedScene(packScene6)
    exports['progressBars']:startUI(24000, "Procesezi Marijuana...")
    Citizen.Wait(24000)
    NetworkStopSynchronisedScene(packScene)
    NetworkStopSynchronisedScene(packScene2)
    NetworkStopSynchronisedScene(packScene3)
    NetworkStopSynchronisedScene(packScene4)
    NetworkStopSynchronisedScene(packScene5)
    NetworkStopSynchronisedScene(packScene6)
    DeleteEntity(dry)
    DeleteEntity(dry2)
    DeleteEntity(leaf)
    DeleteEntity(leaf2)
    DeleteEntity(bag)
    DeleteEntity(bag2)
    DeleteEntity(bud)
    DeleteEntity(bud2)
    DeleteEntity(bud3)
    DeleteEntity(bud4)
    DeleteEntity(bud5)
    DeleteEntity(bud6)
    DeleteEntity(bud7)
    DeleteEntity(bud8)
    DeleteEntity(bud9)
    DeleteEntity(buck)
    DeleteEntity(buck2)
    jobMarijuanaS.finishedMarijuana{loc}
end

function jobMarijuanaF:colecteazaPlanta(planta)
    jobMarijuanaS.canCollect({planta}, function (can)
        if can then
            ExecuteCommand("e parkingmeter")
            exports['progressBars']:startUI(10500, "Culegi Marijuana...")
          
            Citizen.Wait(7500)
            ClearPedTasks(PlayerPedId())
            Citizen.Wait(3000)
            DeleteObject(spawnedPlants[planta].obj)
            spawnedPlants[planta].spawned = false       
            jobMarijuanaS.colecteazaPlanta{planta}
            print("aaasdasd")
            ExecuteCommand("e c")
            exports['fpt-textui']:Close()
        else
            TriggerEvent("fplaytbank:notifications", 'error', 'Aceasta planta este deja culeasa de altcineva', 7500, 'FPlayT')
        end
    end)
end

function jobMarijuanaF:infoliazaMarijuana()

            jobMarijuanaS.hasItems({"marijuana1g", 10}, function (maria)
                jobMarijuanaS.hasItems({"folieplastic", 1}, function (folie)
                    if maria and folie then
                        jobMarijuanaS.takeItems{"marijuana1g", 10}
                        jobMarijuanaS.takeItems{"folieplastic", 1}
                        local hash = GetHashKey("bkr_prop_weed_bag_01a")
                        RequestModel(hash)
                        while not HasModelLoaded(hash) do
                            Citizen.Wait(100)
                            RequestModel(hash)
                        end
                        local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
                        AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 18905), 0.11, 0.09, 0.15, 65.0, 0.0, 0.0, true, true, false, false, 1, true)
                        exports['progressBars']:startUI(5000, "Infoliezi marijuana...")
                        TaskPlayAnim("anim@amb@clubhouse@tutorial@bkr_tut_ig3@", "machinic_loop_mechandplayer", 2.0, 2.0, 5000, 51, 0, false, false, false)
                        FreezeEntityPosition(PlayerPedId(), true)
                        Citizen.Wait(5000)   
                        DeleteObject(prop)
                        ClearPedTasks(PlayerPedId())
                        FreezeEntityPosition(PlayerPedId(), false)
                        jobMarijuanaS.finishedInfoliat{}
                    else
                        jobMarijuanaS.eliberatInfoliere{}
                        TriggerEvent("fplaytbank:notifications", "error", "Ai nevoie de 10 grame de marijuana si de folie de plastic!", 7500, "FPlayT")
                    end
                end)
            end)

    
end

function jobMarijuana.faJoint()
    exports['progressBars']:startUI(5000, "Prepari jointul...")
    Citizen.CreateThread(function()
        TaskPlayAnim("anim@amb@clubhouse@tutorial@bkr_tut_ig3@", "machinic_loop_mechandplayer", 2.0, 2.0, 5000, 51, 0, false, false, false)
        local hash = GetHashKey("prop_cigar_02")
        RequestModel(hash)
        while not HasModelLoaded(hash) do
            Citizen.Wait(0)
            RequestModel(hash)
        end
        local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
        AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.06, -0.03, 0.02, -1.0, 90.0, 0.0, true, true, false, false, 1, true)
        Citizen.Wait(5000)
        DeleteObject(prop) 
    end)
end

Tunnel.bindInterface("jobMarijuana", jobMarijuana)
