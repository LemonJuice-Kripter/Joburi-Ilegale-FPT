local jobTabaccoS = Tunnel.getInterface("jobTabacco", "jobTabacco")
local jobTabaccoF = {}
local canDoJob = false

local coordsLivrare = {
    { 232.32763671875, 672.21655273438, 189.9799041748 },
    { 216.35945129395, 620.37622070312, 187.7552947998 },
    { 184.37721252441, 571.56182861328, 183.34194946289 },
    { 84.986289978027, 561.60479736328, 182.7733001709 },
    { 45.908847808838, 555.8583984375, 180.08198547363 },
    { 224.1257019043, 513.67211914062, 140.76698303223 },
    { 167.39158630371, 473.8034362793, 142.51322937012 },
    { 119.82935333252, 494.46420288086, 147.34283447266 },
    { 107.08453369141, 466.69964599609, 147.55694580078 },
    { 79.972328186035, 486.32192993164, 148.20140075684 },
    { 57.615879058838, 449.54620361328, 147.06387329102 },
    { 42.94953918457, 468.81518554688, 148.09608459473 },
    { -7.8767204284668, 467.77471923828, 145.84146118164 },
    { -66.825492858887, 490.04354858398, 144.87397766113 },
    { -109.95538330078, 501.80609130859, 143.47904968262 },
    { -126.42250823975, 588.25885009766, 204.71055603027 },
    { -185.2180480957, 591.18951416016, 197.82304382324 },
    { -189.36485290527, 618.37017822266, 199.66123962402 },
    { -232.63330078125, 588.20227050781, 190.53552246094 },
    { -293.57598876953, 600.84228515625, 181.57536315918 },
    { -298.84771728516, 635.61834716797, 175.69364929199 },
    { -339.62933349609, 625.52209472656, 171.35673522949 },
    { -353.14636230469, 668.37823486328, 169.07629394531 },
    { -400.05432128906, 664.65093994141, 163.83006286621 },
    { -446.1745300293, 686.32653808594, 153.11906433105 },
    { -476.62344360352, 647.55029296875, 144.38687133789 },
    { -523.18096923828, 628.18090820312, 137.9737701416 },
    { -474.25305175781, 585.93243408203, 128.68392944336 },
    { -520.67669677734, 594.07635498047, 120.83655548096 },
    { -500.63916015625, 551.85284423828, 120.60253143311 },
    { -459.14056396484, 537.08172607422, 121.46027374268 },
    { -426.01348876953, 535.08941650391, 122.42388153076 },
    { -386.90878295898, 504.10244750977, 120.40821075439 },
    { -355.8571472168, 469.80822753906, 112.63666534424 },
    { -311.82238769531, 474.95184326172, 111.82404327393 },
    { -305.1064453125, 431.06488037109, 110.47744750977 },
    { -401.19732666016, 427.56918334961, 112.34884643555 },
    { -450.91354370117, 395.50985717773, 104.77735900879 },
    { -500.07034301758, 398.28146362305, 98.275436401367 },
    { -516.59173583984, 433.44696044922, 97.80793762207 },
    { -560.90710449219, 402.53967285156, 101.81150817871 },
    { -595.63555908203, 393.07354736328, 101.88245391846 },
    { -615.52899169922, 398.25805664062, 101.62136077881 },
    { -469.1901550293, 330.00219726562, 104.7469329834 },
    { -444.26889038086, 342.81048583984, 105.62072753906 },
    { -409.57385253906, 341.39492797852, 108.90744781494 },
    { -371.79602050781, 343.24011230469, 109.94289398193 },
    { -328.02966308594, 369.5881652832, 110.0059967041 },
    { -297.78378295898, 379.82281494141, 112.09733581543 },
    { -214.04254150391, 399.54815673828, 111.28295135498 },
    { -166.38412475586, 423.90756225586, 111.80576324463 },
    { -595.52178955078, 530.4072265625, 107.75444793701 },
    { -580.46954345703, 491.81652832031, 108.90315246582 },
    { -622.94677734375, 489.09628295898, 108.8726272583 },
    { -640.90930175781, 520.54040527344, 109.87781524658 },
    { -667.09497070312, 471.59414672852, 114.13658905029 },
    { -679.0517578125, 512.03375244141, 113.52607727051 },
    { -717.73455810547, 448.63119506836, 106.90912628174 },
    { -762.15594482422, 430.9944152832, 100.193801879886 },
    { -784.75170898438, 459.76312255859, 100.38918304443 },
    { -824.80749511719, 421.98745727539, 92.124290466309 },
    { -842.76239013672, 466.92111206055, 87.596351623535 },
    { -848.60217285156, 508.60354614258, 90.817268371582 },
    { -884.37384033203, 517.96209716797, 92.442726135254 },
    { -873.50500488281, 562.60931396484, 96.619430541992 },
    { -907.43853759766, 545.08917236328, 100.20561981201 },
    { -904.61096191406, 588.2265625, 101.18972015381 },
    { -924.82958984375, 561.35052490234, 100.15752410889 },
    { -974.40600585938, 581.82147216797, 103.14900970459 },
    { -1022.6404418945, 586.86846923828, 103.42942047119 },
    { -1107.6685791016, 594.54034423828, 104.45464324951 },
    { -1090.033203125, 548.52783203125, 103.63327026367 },
    { -1125.3405761719, 548.32135009766, 102.57225036621 },
    { -1146.5313720703, 545.87799072266, 101.9075012207 },
    { -1193.0972900391, 564.02783203125, 100.3394317627 },
    { -1277.8841552734, 497.07904052734, 97.890533447266 },
    { -1258.6275634766, 446.72634887695, 94.735687255859 },
    { -1308.0904541016, 449.00411987305, 100.97008514404 },
    { -1371.5209960938, 443.93151855469, 105.855941772463 },
    { -1343.0603027344, 481.44677734375, 102.7620010376 },
    { -1413.4934082031, 462.1760559082, 109.20855712891 },
    { -1405.4810791016, 526.7919921875, 123.83116149902 },
    { -1452.9125976562, 545.54919433594, 120.96368408203 },
    { -1453.9412841797, 512.28161621094, 117.79638671875 },
    { -1500.4788818359, 523.02905273438, 118.27211761475 },
    { -1495.8796386719, 436.99047851562, 112.49787139893 },
    { -1540.0415039062, 420.54382324219, 110.01399993896 },
    { -1405.1030273438, 561.96051025391, 125.40614318848 },
    { -1346.4556884766, 560.63653564453, 130.53153991699 },
    { -1367.1362304688, 610.75341796875, 133.88981628418 },
    { -1337.0361328125, 606.17834472656, 134.37973022461 },
    { -1277.4411621094, 629.99920654297, 143.2476348877 },
    { -1291.8166503906, 650.43096923828, 141.5016784668 },
    { -1241.3099365234, 674.49346923828, 142.81190490723 },
    { -1196.6665039062, 693.25567626953, 147.42718505859 },
    { -1165.5965576172, 726.83093261719, 155.60673522949 },
    { -1117.7878417969, 761.4404296875, 164.28869628906 },
    { -1130.8295898438, 784.53619384766, 163.8874206543 },
    { -1100.6265869141, 797.86071777344, 167.25604248047 },
    { -1067.5520019531, 795.75769042969, 166.98561096191 },
    { -1056.310546875, 761.44128417969, 167.31571960449 },
    { -1065.0390625, 726.82073974609, 165.47459411621 },
    { -1019.415222168, 719.2998046875, 163.99609375 },
    { -931.46124267578, 690.98907470703, 153.46690368652 },
    { -908.69592285156, 693.75079345703, 151.43586730957 },
    { -884.71594238281, 699.39251708984, 151.27096557617 },
    { -819.33367919922, 696.61547851562, 148.10855102539 },
    { -765.70477294922, 650.49499511719, 145.69776916504 },
    { -733.03894042969, 593.75054931641, 142.47764587402 },
    { -704.19573974609, 588.38818359375, 142.28034973145 },
    { -700.82244873047, 647.01885986328, 155.37046813965 },
    { -747.26129150391, 808.19146728516, 215.0281829834 },
    { -867.40130615234, 784.96606445312, 191.93363952637 },
    { -912.25775146484, 777.23944091797, 187.0064239502 },
    { -931.81597900391, 808.93145751953, 184.78077697754 },
    { -962.73358154297, 814.26861572266, 177.75793457031 },
    { -999.52709960938, 816.96478271484, 173.0495300293 },
    { -972.35992431641, 752.416015625, 176.38136291504 },
    { -658.46936035156, 886.24102783203, 229.30113220215 },
    { -596.96588134766, 851.60876464844, 211.46688842773 },
    { -536.77001953125, 818.18383789062, 197.51025390625 },
    { -494.07702636719, 795.95965576172, 184.3405456543 },
    { -495.80133056641, 738.53625488281, 163.03126525879 },
    { -533.42999267578, 709.54156494141, 153.15475463867 }
}


local hasJob = false
local showedLivrare = false
local showedPlante = {}
local spawnedPlants = {}
local scaunAles = nil

local sitting = false
local sit = ({ 'base_idle_a', 'base_idle_b', 'base_idle_c', 'base_idle_d', 'base_idle_e', 'base_idle_f' })[
    math.random(1, 6)]

local scaune = {
    [1] = {
        coords = vector3(4922.1616210938, -5239.294921875, 1.5230960845948),
        rot = 35.0
    },
    [2] = {
        coords = vector3(4920.5581054688, -5240.2993164062, 1.5230786800384),
        rot = 35.0
    },
    [3] = {
        coords = vector3(4918.2729492188, -5237.3334960938, 1.5225894451142),
        rot = 125.0
    },
    [4] = {
        coords = vector3(4919.8891601562, -5236.2353515625, 1.5226128101348),
        rot = -55.0
    }
}

local showedScaune = {}



CreateObject(GetHashKey('bkr_prop_biker_chair_01'), 5071.3530273438,-4600.75390625,1.8611805438995, false, false, false)

scaune[1].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[1].coords.x, scaune[1].coords.y,
    scaune[1].coords.z, false, false, false)
scaune[2].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[2].coords.x, scaune[2].coords.y,
    scaune[2].coords.z, false, false, false)
scaune[3].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[3].coords.x, scaune[3].coords.y,
    scaune[3].coords.z, false, false, false)
scaune[4].obj = CreateObject(GetHashKey('bkr_prop_biker_chair_01'), scaune[4].coords.x, scaune[4].coords.y,
    scaune[4].coords.z, false, false, false)
SetEntityRotation(scaune[1].obj, 0.0, 0.0, scaune[1].rot)
SetEntityRotation(scaune[2].obj, 0.0, 0.0, scaune[2].rot)
SetEntityRotation(scaune[3].obj, 0.0, 0.0, scaune[3].rot)
SetEntityRotation(scaune[4].obj, 0.0, 0.0, scaune[4].rot)

for k, _ in pairs(scaune) do
    showedScaune[k] = false
end

local plante = {
    -- Randu 1
    [1] = {
        coords = vector3(5384.236328125, -5217.8251953125, 32.738330841064),
        harvested = false
    },
    [2] = {
        coords = vector3(5385.7666015625, -5215.8671875, 32.758960723876),
        harvested = false
    },
    [3] = {
        coords = vector3(5387.0673828125, -5214.1484375, 32.790767669678),
        harvested = false
    },
    [4] = {
        coords = vector3(5388.4155273438, -5212.3974609375, 32.77568435669),
        harvested = false
    },
    [5] = {
        coords = vector3(5389.734375, -5210.6362304688, 32.734928131104),
        harvested = false
    },
    [6] = {
        coords = vector3(5391.0224609375, -5208.71875, 32.65837097168),
        harvested = false
    },
    [7] = {
        coords = vector3(5392.4633789062, -5206.6713867188, 32.601135253906),
        harvested = false
    },
    [8] = {
        coords = vector3(5393.9306640625, -5204.7822265625, 32.650173187256),
        harvested = false
    },
    [9] = {
        coords = vector3(5395.2919921875, -5203.1767578125, 32.650779724122),
        harvested = false
    },
    [10] = {
        coords = vector3(5396.8784179688, -5201.2470703125, 32.662757873536),
        harvested = false
    },
    [11] = {
        coords = vector3(5398.2241210938, -5199.3857421875, 32.62981414795),
        harvested = false
    },
    [12] = {
        coords = vector3(5399.5771484375, -5197.56640625, 32.560855865478),
        harvested = false
    },
    -- Randu 2
    [13] = {
        coords = vector3(5386.576171875, -5219.4858398438, 33.067569732666),
        harvested = false
    },
    [14] = {
        coords = vector3(5387.9965820312, -5217.7006835938, 33.11170578003),
        harvested = false
    },
    [15] = {
        coords = vector3(5389.54296875, -5215.8818359375, 33.168533325196),
        harvested = false
    },
    [16] = {
        coords = vector3(5390.8989257812, -5214.1469726562, 33.164779663086),
        harvested = false
    },
    [17] = {
        coords = vector3(5392.2548828125, -5212.27734375, 33.108661651612),
        harvested = false
    },
    [18] = {
        coords = vector3(5393.6420898438, -5210.4497070312, 33.044219970704),
        harvested = false
    },
    [19] = {
        coords = vector3(5395.109375, -5208.75, 32.997215270996),
        harvested = false
    },
    [20] = {
        coords = vector3(5396.5595703125, -5206.8403320312, 33.053928375244),
        harvested = false
    },
    [21] = {
        coords = vector3(5398.0698242188, -5205.0668945312, 33.050022125244),
        harvested = false
    },
    [22] = {
        coords = vector3(5399.5493164062, -5203.2109375, 33.013191223144),
        harvested = false
    },
    [23] = {
        coords = vector3(5401.0205078125, -5201.4028320312, 32.967044830322),
        harvested = false
    },
    [24] = {
        coords = vector3(5402.3803710938, -5199.6352539062, 32.869979858398),
        harvested = false
    },
    -- Randu 3
    [25] = {
        coords = vector3(5388.3842773438, -5220.9462890625, 33.304794311524),
        harvested = false
    },
    [26] = {
        coords = vector3(5389.85546875, -5219.1171875, 33.359367370606),
        harvested = false
    },
    [27] = {
        coords = vector3(5391.3388671875, -5217.3295898438, 33.420631408692),
        harvested = false
    },
    [28] = {
        coords = vector3(5392.7739257812, -5215.5908203125, 33.451000213624),
        harvested = false
    },
    [29] = {
        coords = vector3(5394.1586914062, -5213.8217773438, 33.423233032226),
        harvested = false
    },
    [30] = {
        coords = vector3(5395.515625, -5212.0751953125, 33.378494262696),
        harvested = false
    },
    [31] = {
        coords = vector3(5397.0961914062, -5210.07421875, 33.362594604492),
        harvested = false
    },
    [32] = {
        coords = vector3(5398.5341796875, -5208.2446289062, 33.344097137452),
        harvested = false
    },
    [33] = {
        coords = vector3(5399.9399414062, -5206.498046875, 33.298950195312),
        harvested = false
    },
    [34] = {
        coords = vector3(5401.34765625, -5204.6806640625, 33.22764968872),
        harvested = false
    },
    [35] = {
        coords = vector3(5402.9404296875, -5202.82421875, 33.177955627442),
        harvested = false
    },
    [36] = {
        coords = vector3(5404.3022460938, -5201.1303710938, 33.076927185058),
        harvested = false
    },
    -- Randu 4
    [37] = {
        coords = vector3(5390.552734375, -5222.6313476562, 33.590042114258),
        harvested = false
    },
    [38] = {
        coords = vector3(5392.025390625, -5220.7045898438, 33.651443481446),
        harvested = false
    },
    [39] = {
        coords = vector3(5393.4453125, -5218.9682617188, 33.721893310546),
        harvested = false
    },
    [40] = {
        coords = vector3(5394.9033203125, -5217.201171875, 33.776763916016),
        harvested = false
    },
    [41] = {
        coords = vector3(5396.3647460938, -5215.4306640625, 33.79413986206),
        harvested = false
    },
    [42] = {
        coords = vector3(5397.751953125, -5213.6381835938, 33.777305603028),
        harvested = false
    },
    [43] = {
        coords = vector3(5399.1845703125, -5211.7749023438, 33.770408630372),
        harvested = false
    },
    [44] = {
        coords = vector3(5400.6479492188, -5209.8388671875, 33.656547546386),
        harvested = false
    },
    [45] = {
        coords = vector3(5401.9145507812, -5208.0395507812, 33.563915252686),
        harvested = false
    },
    [46] = {
        coords = vector3(5403.2915039062, -5206.1420898438, 33.459888458252),
        harvested = false
    },
    [47] = {
        coords = vector3(5404.8662109375, -5204.1108398438, 33.393936157226),
        harvested = false
    },
    [48] = {
        coords = vector3(5406.1860351562, -5202.4541015625, 33.285163879394),
        harvested = false
    },
    -- Randu 5
    [49] = {
        coords = vector3(5392.6948242188, -5224.1518554688, 33.840591430664),
        harvested = false
    },
    [50] = {
        coords = vector3(5394.087890625, -5222.2822265625, 33.890048980712),
        harvested = false
    },
    [51] = {
        coords = vector3(5395.5068359375, -5220.4038085938, 33.944789886474),
        harvested = false
    },
    [52] = {
        coords = vector3(5396.9453125, -5218.5590820312, 33.969203948974),
        harvested = false
    },
    [53] = {
        coords = vector3(5398.3872070312, -5216.7504882812, 33.973735809326),
        harvested = false
    },
    [54] = {
        coords = vector3(5399.609375, -5215.0405273438, 33.956645965576),
        harvested = false
    },
    [55] = {
        coords = vector3(5401.0458984375, -5213.0688476562, 33.960395812988),
        harvested = false
    },
    [56] = {
        coords = vector3(5402.4140625, -5211.24609375, 33.852115631104),
        harvested = false
    },
    [57] = {
        coords = vector3(5403.759765625, -5209.3793945312, 33.772277832032),
        harvested = false
    },
    [58] = {
        coords = vector3(5405.1396484375, -5207.52734375, 33.668354034424),
        harvested = false
    },
    [59] = {
        coords = vector3(5406.6762695312, -5205.7001953125, 33.581142425538),
        harvested = false
    },
    [60] = {
        coords = vector3(5408.0834960938, -5203.83984375, 33.454242706298),
        harvested = false
    },
    -- Randu 6
    [61] = {
        coords = vector3(5395.2607421875, -5226.0737304688, 34.133640289306),
        harvested = false
    },
    [62] = {
        coords = vector3(5396.6040039062, -5224.2055664062, 34.178588867188),
        harvested = false
    },
    [63] = {
        coords = vector3(5397.9702148438, -5222.3276367188, 34.198009490966),
        harvested = false
    },
    [64] = {
        coords = vector3(5399.2758789062, -5220.373046875, 34.178340911866),
        harvested = false
    },
    [65] = {
        coords = vector3(5400.6166992188, -5218.5727539062, 34.16261291504),
        harvested = false
    },
    [66] = {
        coords = vector3(5402.1098632812, -5216.6850585938, 34.18796157837),
        harvested = false
    },
    [67] = {
        coords = vector3(5403.4750976562, -5215.0009765625, 34.199798583984),
        harvested = false
    },
    [68] = {
        coords = vector3(5404.9375, -5213.0556640625, 34.12943649292),
        harvested = false
    },
    [69] = {
        coords = vector3(5406.369140625, -5211.3369140625, 34.063373565674),
        harvested = false
    },
    [70] = {
        coords = vector3(5407.8017578125, -5209.5087890625, 33.970092773438),
        harvested = false
    },
    [71] = {
        coords = vector3(5409.3076171875, -5207.5478515625, 33.8413772583),
        harvested = false
    },
    [72] = {
        coords = vector3(5410.7314453125, -5205.8159179688, 33.678325653076),
        harvested = false
    },
    -- Randu 7
    [73] = {
        coords = vector3(5397.1586914062, -5227.4575195312, 34.344409942626),
        harvested = false
    },
    [74] = {
        coords = vector3(5398.646484375, -5225.5737304688, 34.392852783204),
        harvested = false
    },
    [75] = {
        coords = vector3(5400.0571289062, -5223.7866210938, 34.418071746826),
        harvested = false
    },
    [76] = {
        coords = vector3(5401.3579101562, -5222.0419921875, 34.403175354004),
        harvested = false
    },
    [77] = {
        coords = vector3(5402.7045898438, -5220.20703125, 34.385158538818),
        harvested = false
    },
    [78] = {
        coords = vector3(5404.119140625, -5218.365234375, 34.383121490478),
        harvested = false
    },
    [79] = {
        coords = vector3(5405.5874023438, -5216.5693359375, 34.376789093018),
        harvested = false
    },
    [80] = {
        coords = vector3(5407.1811523438, -5214.7866210938, 34.316024780274),
        harvested = false
    },
    [81] = {
        coords = vector3(5408.6147460938, -5213.0327148438, 34.255012512208),
        harvested = false
    },
    [82] = {
        coords = vector3(5410.115234375, -5211.173828125, 34.172954559326),
        harvested = false
    },
    [83] = {
        coords = vector3(5411.6337890625, -5209.5302734375, 34.06536102295),
        harvested = false
    },
    [84] = {
        coords = vector3(5413.076171875, -5207.7397460938, 33.92770767212),
        harvested = false
    },
    -- Randu 8
    [85] = {
        coords = vector3(5399.5961914062, -5229.2465820312, 34.61540222168),
        harvested = false
    },
    [86] = {
        coords = vector3(5401.0737304688, -5227.587890625, 34.653930664062),
        harvested = false
    },
    [87] = {
        coords = vector3(5402.4555664062, -5225.6943359375, 34.67705154419),
        harvested = false
    },
    [88] = {
        coords = vector3(5403.8271484375, -5223.9155273438, 34.673793792724),
        harvested = false
    },
    [89] = {
        coords = vector3(5405.3466796875, -5222.1640625, 34.668426513672),
        harvested = false
    },
    [90] = {
        coords = vector3(5406.7436523438, -5220.322265625, 34.633308410644),
        harvested = false
    },
    [91] = {
        coords = vector3(5408.1225585938, -5218.4926757812, 34.58387374878),
        harvested = false
    },
    [92] = {
        coords = vector3(5409.7041015625, -5216.8154296875, 34.512470245362),
        harvested = false
    },
    [93] = {
        coords = vector3(5411.0629882812, -5214.9965820312, 34.455520629882),
        harvested = false
    },
    [94] = {
        coords = vector3(5412.6274414062, -5213.052734375, 34.386936187744),
        harvested = false
    },
    [95] = {
        coords = vector3(5414.0073242188, -5211.3579101562, 34.292037963868),
        harvested = false
    },
    [96] = {
        coords = vector3(5415.3872070312, -5209.4248046875, 34.173999786376),
        harvested = false
    },
    -- Randu 9
    [97] = {
        coords = vector3(5401.9892578125, -5231.0810546875, 34.815082550048),
        harvested = false
    },
    [98] = {
        coords = vector3(5403.443359375, -5229.328125, 34.85478591919),
        harvested = false
    },
    [99] = {
        coords = vector3(5404.8198242188, -5227.5966796875, 34.873332977294),
        harvested = false
    },
    [100] = {
        coords = vector3(5406.1875, -5225.8520507812, 34.862174987792),
        harvested = false
    },
    [101] = {
        coords = vector3(5407.8276367188, -5223.94140625, 34.829864501954),
        harvested = false
    },
    [102] = {
        coords = vector3(5409.2504882812, -5222.29296875, 34.75357055664),
        harvested = false
    },
    [103] = {
        coords = vector3(5410.7705078125, -5220.5, 34.667705535888),
        harvested = false
    },
    [104] = {
        coords = vector3(5412.2543945312, -5218.845703125, 34.644412994384),
        harvested = false
    },
    [105] = {
        coords = vector3(5413.7880859375, -5217.0341796875, 34.610553741456),
        harvested = false
    },
    [106] = {
        coords = vector3(5415.33203125, -5215.2543945312, 34.586502075196),
        harvested = false
    },
    [107] = {
        coords = vector3(5416.8657226562, -5213.517578125, 34.558067321778),
        harvested = false
    },
    [108] = {
        coords = vector3(5418.4296875, -5211.8286132812, 34.50458908081),
        harvested = false
    },
    -- Randu 10
    [109] = {
        coords = vector3(5404.9296875, -5233.5083007812, 34.998615264892),
        harvested = false
    },
    [110] = {
        coords = vector3(5406.3627929688, -5231.6762695312, 35.034187316894),
        harvested = false
    },
    [111] = {
        coords = vector3(5407.8857421875, -5229.7866210938, 35.082424163818),
        harvested = false
    },
    [112] = {
        coords = vector3(5409.1401367188, -5228.1196289062, 35.057929992676),
        harvested = false
    },
    [113] = {
        coords = vector3(5410.693359375, -5226.3041992188, 35.015087127686),
        harvested = false
    },
    [114] = {
        coords = vector3(5412.056640625, -5224.4838867188, 34.923198699952),
        harvested = false
    },
    [115] = {
        coords = vector3(5413.5185546875, -5222.6645507812, 34.830783843994),
        harvested = false
    },
    [116] = {
        coords = vector3(5414.9951171875, -5220.9375, 34.805362701416),
        harvested = false
    },
    [117] = {
        coords = vector3(5416.5122070312, -5219.1391601562, 34.765727996826),
        harvested = false
    },
    [118] = {
        coords = vector3(5417.9301757812, -5217.2333984375, 34.765411376954),
        harvested = false
    },
    [119] = {
        coords = vector3(5419.4204101562, -5215.4599609375, 34.766067504882),
        harvested = false
    },
    [120] = {
        coords = vector3(5420.96484375, -5213.765625, 34.757545471192),
        harvested = false
    },
    -- Randu 11
    [121] = {
        coords = vector3(5407.4072265625, -5235.3740234375, 35.058723449708),
        harvested = false
    },
    [122] = {
        coords = vector3(5408.9077148438, -5233.52734375, 35.099933624268),
        harvested = false
    },
    [123] = {
        coords = vector3(5410.3862304688, -5231.8090820312, 35.152362823486),
        harvested = false
    },
    [124] = {
        coords = vector3(5411.8413085938, -5230.029296875, 35.179870605468),
        harvested = false
    },
    [125] = {
        coords = vector3(5413.40234375, -5228.2661132812, 35.185470581054),
        harvested = false
    },
    [126] = {
        coords = vector3(5414.841796875, -5226.537109375, 35.148307800292),
        harvested = false
    },
    [127] = {
        coords = vector3(5416.080078125, -5224.5625, 35.081142425538),
        harvested = false
    },
    [128] = {
        coords = vector3(5417.6176757812, -5222.7880859375, 34.970546722412),
        harvested = false
    },
    [129] = {
        coords = vector3(5419.0288085938, -5221.0463867188, 34.913578033448),
        harvested = false
    },
    [130] = {
        coords = vector3(5420.3198242188, -5218.99609375, 34.925724029542),
        harvested = false
    },
    [131] = {
        coords = vector3(5421.666015625, -5217.154296875, 34.952236175538),
        harvested = false
    },
    [132] = {
        coords = vector3(5423.1713867188, -5215.283203125, 34.980350494384),
        harvested = false
    },
    -- Randu 12
    [133] = {
        coords = vector3(5410.2973632812, -5237.3500976562, 35.179203033448),
        harvested = false
    },
    [134] = {
        coords = vector3(5411.5942382812, -5235.603515625, 35.167797088624),
        harvested = false
    },
    [135] = {
        coords = vector3(5413.078125, -5233.7392578125, 35.25908279419),
        harvested = false
    },
    [136] = {
        coords = vector3(5414.3579101562, -5231.9106445312, 35.269634246826),
        harvested = false
    },
    [137] = {
        coords = vector3(5415.6884765625, -5229.9736328125, 35.295833587646),
        harvested = false
    },
    [138] = {
        coords = vector3(5417.0805664062, -5228.224609375, 35.29706954956),
        harvested = false
    },
    [139] = {
        coords = vector3(5418.4458007812, -5226.2646484375, 35.29175567627),
        harvested = false
    },
    [140] = {
        coords = vector3(5419.8950195312, -5224.5219726562, 35.211101531982),
        harvested = false
    },
    [141] = {
        coords = vector3(5421.4501953125, -5222.7358398438, 35.168380737304),
        harvested = false
    },
    [142] = {
        coords = vector3(5422.8852539062, -5220.9116210938, 35.221767425538),
        harvested = false
    },
    [143] = {
        coords = vector3(5424.4653320312, -5219.0634765625, 35.273128509522),
        harvested = false
    },
    [144] = {
        coords = vector3(5425.853515625, -5217.2426757812, 35.279571533204),
        harvested = false
    }
}

for k, v in pairs(plante) do
    showedPlante[k] = false
end

for k, v in pairs(plante) do
    spawnedPlants[k] = {}
    spawnedPlants[k].spawned = false
    spawnedPlants[k].obj = nil
end

RegisterNetEvent("vRP:onJobChange")
AddEventHandler("vRP:onJobChange", function(job)
    job = job
    if job == 'Traficant Tobacco' then
        canDoJob = true
    else
        canDoJob = false
        hasJob = false
        if blip then
            RemoveBlip(blip)
        end
    end
end)

RegisterNetEvent("fpt-tabacco:client:info")
AddEventHandler("fpt-tabacco:client:info", function()
    TriggerEvent('iceNotify', 'INFO', 'Ai nevoie de tutun si foite de tutun sa poti sa faci trabucuri.'
        , 7500, 'Ursoi')
end)

RegisterNetEvent("fpt-tabacco:client:gps")
AddEventHandler("fpt-tabacco:client:gps", function()
    TriggerEvent('fplaytbank:notifications', 'INFO', 'O sa primesti o locatie pe GPS!', 7500, 'Ursoi')
    SetNewWaypoint(5396.7216796875, -5217.1079101562)
end)

RegisterNetEvent("fpt-tabacco:client:locatie")
AddEventHandler("fpt-tabacco:client:locatie", function()
    TriggerEvent('fplaytbank:notifications', 'INFO',
        'Nu, saptamanal se inchiriaza la niste baieti smecheri care au bani la care trebuie sa platesti taxe.', 7500,
        'Ursoi')
end)

RegisterNetEvent("fpt-tabacco:client:alexia")
AddEventHandler("fpt-tabacco:client:alexia", function()
    TriggerEvent('fplaytbank:notifications', 'INFO',
        'Sunt Ursoi puiu, ma ocup de locatia asta. Mai ai multe intrebari?', 7500, 'Ursoi')
end)

RegisterNetEvent("fpt-tabacco:client:addGroup")
AddEventHandler("fpt-tabacco:client:addGroup", function()
    jobTabaccoS.setJob { true }
end)

RegisterNetEvent("fpt-tabacco:client:removeGroup")
AddEventHandler("fpt-tabacco:client:removeGroup", function()
    TriggerEvent('fplaytbank:notifications', 'INFO', 'Gata puisor? Ne parasesti deja?', 7500, 'Ursoi')
    jobTabaccoS.setJob { false }
end)

CreateThread(function()
    while true do
        Citizen.Wait(200)

        Citizen.Wait(2000)
        local coordonate = vector3(5327.9106445312, -5195.140625, 31.93155670166)


        local distanta = GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), coordonate, true)
        if distanta < 100 then
            --jobTabaccoS.getPlants({}, function(plante)
            for k, v in pairs(plante or {}) do
                if not plante[k].harvested and not spawnedPlants[k].spawned then
                    spawnedPlants[k].obj = CreateObject(GetHashKey('prop_plant_fern_02a'), v.coords.x, v.coords.y,
                        v.coords.z - 1, false, false, false)
                    SetEntityAsMissionEntity(spawnedPlants[k].obj, false, false)
                    FreezeEntityPosition(spawnedPlants[k].obj, true)
                    spawnedPlants[k].spawned = true
                else
                    if plante[k].harvested and spawnedPlants[k].spawned then
                        DeleteEntity(spawnedPlants[k].obj)
                        spawnedPlants[k].obj = nil
                        spawnedPlants[k].spawned = false
                    end
                end
            end
            --end)
        end

    end
end)

local inRange = false

CreateThread(function()
    while true do
        Citizen.Wait(0)

        inRange = false
        local dist
        local pdist

        for k, v in pairs(plante) do

            if v.harvested == false then
                pos = GetEntityCoords(GetPlayerPed(-1), true)

                dist = GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), v.coords, true)
                if dist < 1 then

                    local obj = GetClosestObjectOfType(pos.x, pos.y, pos.z, 1, GetHashKey('prop_plant_fern_02a'),
                        false)
                    if not showedPlante[k] and obj then
                        exports['fpt-textui']:Open('[E] Culege planta', 'darkblue', 'left')
                        showedPlante[k] = true
                    end
                    inRange = true
                    if IsControlJustPressed(0, 38) then
                        jobTabaccoF:colecteazaPlanta(k)
                        exports['fpt-textui']:Close()
                    end
                else
                    if showedPlante[k] then
                        exports['fpt-textui']:Close()
                        showedPlante[k] = false
                    end
                end
            end
        end

        for k, v in pairs(scaune) do

            pdist = GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), v.coords, true)
            if pdist < 1.5 and not sitting then
                if not showedScaune[k] then
                    exports['fpt-textui']:Open('[E] Aseaza-te', 'darkblue', 'left')
                    showedScaune[k] = true
                end
                inRange = true
                if IsControlJustPressed(0, 38) then

                    male = 0
                    offset = GetObjectOffsetFromCoords(GetEntityCoords(scaune[k].obj),
                        GetEntityHeading(scaune[k].obj), 0.0, -1.00, -0.08)
                    if GetEntityModel(PlayerPedId()) > 0 then male = 1 end

                    anim = 'anim_casino_a@amb@casino@games@slots@male'
                    if male == 1 then
                        anim = 'anim_casino_a@amb@casino@games@slots@female'
                    end

                    RequestAnimDict(anim)
                    while not HasAnimDictLoaded(anim) do
                        Citizen.Wait(1)
                    end
                    local rot = vector3(0, 0, scaune[k].rot - 185)
                    local scena = NetworkCreateSynchronisedScene(offset, rot, 2, 1, 0, 1065353216, 0,
                        1065353216)

                    NetworkAddPedToSynchronisedScene(PlayerPedId(), scena, anim, sit, 2.0, 2.0, 13, 16, 2.0,
                        0)
                    NetworkStartSynchronisedScene(scena)
                    exports['fpt-textui']:Close()
                    sitting = true
                    TriggerEvent("mt:missiontext",
                        "~r~[H]~w~ Ridica-te | ~r~[G]~w~ Planta Tutun | ~r~[V]~w~ Trabuc | ~r~[C]~w~ Pune in cutie"
                        , 15000)
                    scaunAles = k
                    CreateThread(function()
                        while sitting do Wait(5)
                            DisableAllControlActions(0)
                            for i = 1, 7 do
                                EnableControlAction(0, i)
                            end
                        end
                    end)

                end
            else
                if showedScaune[k] and not sitting then
                    exports['fpt-textui']:Close()
                    showedScaune[k] = false
                end
            end
        end










        if sitting then

            inRange = true
            if IsDisabledControlJustPressed(0, 74) then
                jobTabaccoS.finishedSit { scaunAles }
                exports['fpt-textui']:Close()
                sitting = false
                anim = 'anim_casino_a@amb@casino@games@slots@male'
                if male == 1 then
                    anim = 'anim_casino_a@amb@casino@games@slots@female'
                end

                RequestAnimDict(anim)
                while not HasAnimDictLoaded(anim) do
                    Citizen.Wait(1)
                end
                local rot = vector3(0, 0, scaune[scaunAles].rot - 185)
                local scena = NetworkCreateSynchronisedScene(offset, rot, 2, 1, 0, 1065353216, 0, 1065353216)
                animatie = ({ 'exit_left', 'exit_right' })[math.random(1, 2)]
                NetworkAddPedToSynchronisedScene(PlayerPedId(), scena, anim, animatie, 2.0, 2.0, 13, 16, 0, 0)
                NetworkStartSynchronisedScene(scena)
                Citizen.Wait(3000)
                ClearPedTasks(PlayerPedId())
            end

            if IsDisabledControlJustPressed(0, 47) then
                jobTabaccoF:proceseazaTutun()
            end
            if IsDisabledControlJustPressed(0, 0) then
                jobTabaccoF:proceseazaTrabuc()
            end
            if IsDisabledControlJustPressed(0, 26) then
                jobTabaccoF:proceseazaCutie()
            end

            if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), scaune[scaunAles].coords, true) > 2 then
                jobTabaccoS.finishedSit { scaunAles }
                exports['fpt-textui']:Close()
                sitting = false
                anim = 'anim_casino_a@amb@casino@games@slots@male'
                if male == 1 then
                    anim = 'anim_casino_a@amb@casino@games@slots@female'
                end

                RequestAnimDict(anim)
                while not HasAnimDictLoaded(anim) do
                    Citizen.Wait(1)
                end
                local rot = vector3(0, 0, scaune[scaunAles].rot - 185)
                local scena = NetworkCreateSynchronisedScene(offset, rot, 2, 1, 0, 1065353216, 0, 1065353216)
                animatie = ({ 'exit_left', 'exit_right' })[math.random(1, 2)]
                NetworkAddPedToSynchronisedScene(PlayerPedId(), scena, anim, animatie, 2.0, 2.0, 13, 16, 0, 0)
                NetworkStartSynchronisedScene(scena)
                Citizen.Wait(3000)
                ClearPedTasks(PlayerPedId())
            end
        end



















        local distLivrare = GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), position, true)
        if distLivrare < 10 then
            inRange = true
            DrawMarker(20, position.x, position.y, position.z + 0.1, 0, 0, 0, 0, 0, 0, 0.35, 0.35, -0.60, 230, 0
                , 0, 85, 0)
        end
        if distLivrare < 2 then
            inRange = true
            if not showedLivrare then
                exports['fpt-textui']:Open('[E] Bate la usa', 'darkblue', 'left')
                showedLivrare = true
            end
            if IsControlJustPressed(0, 38) then
                jobTabaccoF:livreaza()
                exports['fpt-textui']:Close()
            end
        else
            if showedLivrare then
                exports['fpt-textui']:Close()
                showedLivrare = false
            end
        end


        if not inRange then
            Citizen.Wait(1000)
        end

    end
end)

function jobTabaccoF:livreaza()
    jobTabaccoS.hasCutie({}, function(has)
        if has then
            exports['progressBars']:startUI(15000, "Livrezi...")
            local hash = GetHashKey("prop_cigar_pack_02")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(100)
                RequestModel(hash)
            end
            playAnim("timetable@jimmy@doorknock@", "knockdoor_idle", 2.0, 2.0, 5000, 51, 0, false, false, false)
            Citizen.Wait(5000)
            playAnim("anim@mugging@victim@toss_ped@", "throw_object_right_pocket_male", 2.0, 2.0, 2000, 51, 0, false,
                false, false)
            Citizen.Wait(300)
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.07, -0.01, -0.04, 0.0, 0.0
                , 190.0, true, true, false, false, 1, true)
            Citizen.Wait(1700)
            playAnim("tunf_iaa_mcs1-1", "mp_m_freemode_01^3_dual-1", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(3000)
            playAnim("mp_common", "givetake1_b", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(1500)
            DeleteObject(prop)
            Citizen.Wait(3500)

            hasJob = false
            jobTabaccoS.livreaza {}
            ClearPedTasks(PlayerPedId())
        else
            TriggerEvent('fplaytbank:notifications', 'error', 'Nu ai trabucurile la tine!', 7500, 'Client')
        end
    end)
end

RegisterNetEvent("syncplant")
AddEventHandler("syncplant", function(plantid, ft)
    print("aaaa")
    spawnedPlants[plantid].harvested = ft
    spawnedPlants[plantid].spawned = ft
    DeleteEntity(spawnedPlants[plantid].obj)
end)

RegisterNetEvent("livreazatabaco")
AddEventHandler("livreazatabaco", function()
    hasJob = true
    if blip then
        RemoveBlip(blip)
    end
    local x, y, z = table.unpack(coordsLivrare[math.random(1, #coordsLivrare)])
    position = vector3(x, y, z)
    blip = AddBlipForCoord(position.x, position.y, position.z)
    SetBlipAsShortRange(blip, true)
    SetBlipRoute(blip, true)
    SetBlipScale(blip, 0.6)
    SetBlipSprite(blip, 501)
    SetBlipColour(blip, 31)
    SetBlipRouteColour(blip, 31)
    strada = GetStreetNameAtCoord(position.x, position.y, position.z, Citizen.ResultAsInteger(),
        Citizen.ResultAsInteger())
    numeStrada = GetStreetNameFromHashKey(strada)
    jobTabaccoS.trimiteMail { numeStrada }
end)

function jobTabaccoF:colecteazaPlanta(planta1)

    jobTabaccoS.canCollect({ planta1 }, function(planta)
        if planta then
            exports['progressBars']:startUI(10500, "Colectezi tutun...")
            ExecuteCommand("e parkingmeter")
            Citizen.Wait(7500)
            ClearPedTasks(PlayerPedId())
            Citizen.Wait(3000)
            print("planta " .. planta1)
            print("obj" .. spawnedPlants[planta1].obj)


            jobTabaccoS.colecteazaPlanta { planta1 }
            exports['fpt-textui']:Close()
        else
            TriggerEvent("fplaytbank:notifications", 'error', 'Aceasta planta este deja culeasa de altcineva', 7500,
                'FPlayT')
        end
    end)
end

function jobTabaccoF:proceseazaTutun()
    jobTabaccoS.hasItemsTutun({}, function(has)
        if has then
            exports['progressBars']:startUI(5000, "Procesezi planta de tutun...")
            TaskPlayAnim("anim@amb@business@weed@weed_sorting_seated@", "sorter_left_sort_v1_sorter01", 2.0, 2.0, 5000,
                51, 0
                , false, false, false)
            local hash = GetHashKey("p_cs_leaf_s")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(0)
                RequestModel(hash)
            end
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.09, -0.02, -0.04, -90.0,
                0.0, 0.0, true, true, false, false, 1, true)
            Citizen.Wait(5000)
            DeleteObject(prop)
            jobTabaccoS.proceseazaTutunul {}
        else
            TriggerEvent("fplaytbank:notifications", 'error', 'Nu ai materialele necesare [1x Planta Tutun]', 7500,
                'FPlayT')
        end
    end)

end

function jobTabaccoF:proceseazaCutie()
    jobTabaccoS.hasItemsCutie({}, function(has)
        if has then
            exports['progressBars']:startUI(5000, "Pui trabucurile in cutie...")
            TaskPlayAnim("anim@amb@business@weed@weed_sorting_seated@", "sorter_left_sort_v1_sorter01", 2.0, 2.0, 5000,
                51, 0
                , false, false, false)
            local hash = GetHashKey("prop_cigar_pack_02")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(100)
                RequestModel(hash)
            end
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.07, -0.01, -0.04, 0.0, 0.0
                , 190.0, true, true, false, false, 1, true)
            Citizen.Wait(5000)
            DeleteObject(prop)
            jobTabaccoS.proceseazaCutia {}
        else
            TriggerEvent("fplaytbank:notifications", 'error', 'Nu ai materialele necesare [5x Trabuc]', 7500, 'FPlayT')
        end
    end)

end

function jobTabaccoF:proceseazaTrabuc()
    jobTabaccoS.hasItemsTrabuc({}, function(has)
        if has then
            exports['progressBars']:startUI(5000, "Procesezi trabucul...")
            TaskPlayAnim("anim@amb@business@weed@weed_sorting_seated@", "sorter_left_sort_v1_sorter01", 2.0, 2.0, 5000,
                51, 0
                , false, false, false)
            local hash = GetHashKey("prop_cigar_02")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(0)
                RequestModel(hash)
            end
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.06, -0.03, 0.02, -1.0,
                90.0, 0.0, true, true, false, false, 1, true)
            Citizen.Wait(5000)
            DeleteObject(prop)
            jobTabaccoS.proceseazaTrabucul {}
        else
            TriggerEvent("fplaytbank:notifications", 'error', 'Nu ai materialele necesare [1x Foita de tutun, 1x Tutun]'
                , 7500, 'FPlayT')
        end
    end)

end
