local Proxy = module("vrp", "lib/Proxy")
local Tunnel = module("vrp", "lib/Tunnel")
nS = {}
vRP = Proxy.getInterface("vRP")

SvTbco = {}
Tunnel.bindInterface("jobTabacco", SvTbco)
Proxy.addInterface("jobTabacco", SvTbco)
ClTbco = Tunnel.getInterface("jobTabacco", "jobTabacco")

collects = {
}


function SvTbco.canCollect(what)
    if collects[what] == nil or collects[what] == false then
        collects[what] = true

        return true
    else
        return false
    end
end

function SvTbco.colecteazaPlanta(what)
    TriggerClientEvent("syncplant", -1, what, true)
    collects[what] = true
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "plantatrabuc", 1, true })
    Wait(30000)
    collects[what] = false
    TriggerClientEvent("syncplant", -1, what, false)
end

function SvTbco.hasItemsTutun()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "plantatrabuc", 1, true }) then
        return true
    end
    return false
end

function SvTbco.proceseazaTutunul()
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "trabucN", 1, true })
end

function SvTbco.hasItemsTrabuc()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "trabucN", 1, true }) then
        return true
    end
    return false
end

function SvTbco.proceseazaTrabucul()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "trabuc", 1, true })
end

function SvTbco.hasItemsCutie()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "trabuc", 1, true }) and
        vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "cutie", 1, true }) then
        return true
    end
    return false
end

function SvTbco.proceseazaCutia()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cutietrabuc", 1, true })
end
