_G["Proxy"], _G["Tunnel"] = module("vrp", "lib/Proxy"), module("vrp", "lib/Tunnel");
_G["vRP"], _G["vRPclient"], _G["playerTable"], _G["utils"] = Proxy["getInterface"] [=[vRP]=],
    Tunnel["getInterface"]([=[vRP]=], [=[jobs-utils]=]), {}, {};

cfg = {
    ["clientName"] = "Road"; --Nickname-ul pe care mi-l dati in momentul cumpararii
    ["jobsCfg"] = {
        ["rewardType"] = "money"; -- money(bani normali) sau dirtymoney(bani murdari) -> item
        ["respawnPlantsTime"] = 60; -- timpul de respawn a unei plate dupa ce a fost culeasa (timp in secunde)
        ["Traficant de Cocaina"] = {
            ["ore"] = 150; -- ore necesare
            ["onlyMafiaPermission"] = true; -- doar mafiotii au acces
            ["mafiaFTypes"] = { "Mafie", "Gang" };
            ["reward"] = 1385; -- suma per livrare(10G Cocaina)
        };
        ["Traficant de Etnobotanice"] = {
            ["ore"] = 110; -- ore necesare
            ["onlyMafiaPermission"] = true; -- doar mafiotii au acces
            ["mafiaFTypes"] = { "Mafie", "Gang" };
            ["rewardPerItemPulse"] = 575; -- suma per 1x Pulse
            ["rewardPerItemSpecialGold"] = 629; -- suma per 1x Special Gold
            -- se aduna reward Pulse + reward Special Gold
        };
        ["Traficant de Marijuana"] = {
            ["ore"] = 130; -- ore necesare
            ["onlyMafiaPermission"] = true; -- doar mafiotii au acces
            ["mafiaFTypes"] = { "Mafie", "Gang" };
            ["reward"] = 1385; -- suma per livrare(10G Marijuana)
        };
        ["Traficant de Metamfetamina"] = {
            ["ore"] = 150; -- ore necesare
            ["onlyMafiaPermission"] = true; -- doar mafiotii au acces
            ["mafiaFTypes"] = { "Mafie", "Gang" };
            ["reward"] = 1385; -- suma per livrare(10G Metamfetamina)
        };
        ["Traficant Tobacco"] = {
            ["ore"] = 110; -- ore necesare
            ["onlyMafiaPermission"] = true; -- doar mafiotii au acces
            ["mafiaFTypes"] = { "Mafie", "Gang" };
            ["reward"] = 1385; -- suma per livrare(cutie de trabucuri)
        };
    };
    ["reloadSkinEvent"] = { ["ev"] = "raid_clothes:incarcaHainele", ["dv"] = "client", ["ag"] = {} }; -- ev => event, dv => server/client, ag => args;
    ["DBDriver"] = "oxmysql"; -- disponibil momentan doar ghmattimysql/oxmysql
    ["trimiteEmailFunction"] = function(...)
        local args = { ... };
        local player, strada, pachete = tonumber(args[1]), tostring(args[2]), tonumber(args[3]);
        if not (player and strada and pachete) then return end
        ; end;
};



