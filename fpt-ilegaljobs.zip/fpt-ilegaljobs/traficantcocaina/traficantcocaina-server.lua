local Proxy = module("vrp", "lib/Proxy")
local Tunnel = module("vrp", "lib/Tunnel")

vRP = Proxy.getInterface("vRP")

Svmtfa = {}
Tunnel.bindInterface("jobCocaina", Svmtfa)
Proxy.addInterface("jobCocaina", Svmtfa)
ClTbco = Tunnel.getInterface("jobCocaina", "jobCocaina")

collects = {
}
print("aa")

function Svmtfa.canCollect(what)
    if collects[what] == nil or collects[what] == false then
        collects[what] = true

        return true
    else
        return false
    end
end

function Svmtfa.colecteazaPlanta(what)
    print("aadsds")
    TriggerClientEvent("syncplant2", -1, what, true)
    collects[what] = true
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "frunzacoca", 1, true })
    Wait(30000)
    collects[what] = false
    TriggerClientEvent("syncplant2", -1, what, false)
end

function Svmtfa.hasItems(ce,cat)
    print("aaa")
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), ce, cat, true }) then
        if ce =="folieplastic"then
            vRP.giveInventoryItem({ vRP.getUserId({ source }), "cocaina10g", 1, true })
        end
        return true
    end
    return false
end

function Svmtfa.finishedFrunze()
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cocaina1g", 1, true })
end
function Svmtfa.finishedCocaina()
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cocaina1g", 1, true })
end

function Svmtfa.hasItemsPulse()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "ots", 1, true }) and vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "ingr", 1, true }) then
        return true
    end
    return false
end
function Svmtfa.hasItemsGold()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "Acetona", 1, true }) and vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "ingr", 1, true }) then
        return true
    end
    return false
end

function Svmtfa.finishedFrunze()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cocainaneprocesata", 1, true })
end
function Svmtfa.finishedInfoliat()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cocaina10g", 1, true })
end

function Svmtfa.hasItemsCutie()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "trabuc", 1, true }) and
        vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "cutie", 1, true }) then
        return true
    end
    return false
end

function Svmtfa.proceseazaCutia()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cutietrabuc", 1, true })
end
