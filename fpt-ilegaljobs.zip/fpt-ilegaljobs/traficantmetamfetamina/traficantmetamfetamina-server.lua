local Proxy = module("vrp", "lib/Proxy")
local Tunnel = module("vrp", "lib/Tunnel")

vRP = Proxy.getInterface("vRP")

Svmtfa = {}
Tunnel.bindInterface("jobMetamfetamina", Svmtfa)
Proxy.addInterface("jobMetamfetamina", Svmtfa)
ClTbco = Tunnel.getInterface("jobMetamfetamina", "jobMetamfetamina")

collects = {
}


function Svmtfa.canCollect(what)
    if collects[what] == nil or collects[what] == false then
        collects[what] = true

        return true
    else
        return false
    end
end

function Svmtfa.colecteazaPlanta(what)
    TriggerClientEvent("syncplant", -1, what, true)
    collects[what] = true
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "plantatrabuc", 1, true })
    Wait(30000)
    collects[what] = false
    TriggerClientEvent("syncplant", -1, what, false)
end

function Svmtfa.hasItems(ce,cat)
    print("aaa")
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), ce, cat, true }) then
        return true
    end
    return false
end

function Svmtfa.finishedMetamfetamina()
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "metamfetamina1g", 1, true })
end

function Svmtfa.hasItemsTrabuc()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "trabucN", 1, true }) then
        return true
    end
    return false
end

function Svmtfa.proceseazaTrabucul()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "trabuc", 1, true })
end

function Svmtfa.hasItemsCutie()
    if vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "trabuc", 1, true }) and
        vRP.tryGetInventoryItem({ vRP.getUserId({ source }), "cutie", 1, true }) then
        return true
    end
    return false
end

function Svmtfa.proceseazaCutia()
    print("aaa")
    vRP.giveInventoryItem({ vRP.getUserId({ source }), "cutietrabuc", 1, true })
end
