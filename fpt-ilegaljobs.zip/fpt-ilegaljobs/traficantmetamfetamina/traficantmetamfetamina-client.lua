local jobMetamfetaminaS = Tunnel.getInterface("jobMetamfetamina", "jobMetamfetamina")
local jobMetamfetaminaF = {}
local canDoJob = true

local coordsLivrare = {
    {232.32763671875,672.21655273438,189.9799041748},
    {216.35945129395,620.37622070312,187.7552947998},
    {184.37721252441,571.56182861328,183.34194946289},
    {84.986289978027,561.60479736328,182.7733001709},
    {45.908847808838,555.8583984375,180.08198547363},
    {224.1257019043,513.67211914062,140.76698303223},
    {167.39158630371,473.8034362793,142.51322937012},
    {119.82935333252,494.46420288086,147.34283447266},
    {107.08453369141,466.69964599609,147.55694580078},
    {79.972328186035,486.32192993164,148.20140075684},
    {57.615879058838,449.54620361328,147.06387329102},
    {42.94953918457,468.81518554688,148.09608459473},
    {-7.8767204284668,467.77471923828,145.84146118164},
    {-66.825492858887,490.04354858398,144.87397766113},
    {-109.95538330078,501.80609130859,143.47904968262},
    {-126.42250823975,588.25885009766,204.71055603027},
    {-185.2180480957,591.18951416016,197.82304382324},
    {-189.36485290527,618.37017822266,199.66123962402},
    {-232.63330078125,588.20227050781,190.53552246094},
    {-293.57598876953,600.84228515625,181.57536315918},
    {-298.84771728516,635.61834716797,175.69364929199},
    {-339.62933349609,625.52209472656,171.35673522949},
    {-353.14636230469,668.37823486328,169.07629394531},
    {-400.05432128906,664.65093994141,163.83006286621},
    {-446.1745300293,686.32653808594,153.11906433105},
    {-476.62344360352,647.55029296875,144.38687133789},
    {-523.18096923828,628.18090820312,137.9737701416},
    {-474.25305175781,585.93243408203,128.68392944336},
    {-520.67669677734,594.07635498047,120.83655548096},
    {-500.63916015625,551.85284423828,120.60253143311},
    {-459.14056396484,537.08172607422,121.46027374268},
    {-426.01348876953,535.08941650391,122.42388153076},
    {-386.90878295898,504.10244750977,120.40821075439},
    {-355.8571472168,469.80822753906,112.63666534424},
    {-311.82238769531,474.95184326172,111.82404327393},
    {-305.1064453125,431.06488037109,110.47744750977},
    {-401.19732666016,427.56918334961,112.34884643555},
    {-450.91354370117,395.50985717773,104.77735900879},
    {-500.07034301758,398.28146362305,98.275436401367},
    {-516.59173583984,433.44696044922,97.80793762207},
    {-560.90710449219,402.53967285156,101.81150817871},
    {-595.63555908203,393.07354736328,101.88245391846},
    {-615.52899169922,398.25805664062,101.62136077881},
    {-469.1901550293,330.00219726562,104.7469329834},
    {-444.26889038086,342.81048583984,105.62072753906},
    {-409.57385253906,341.39492797852,108.90744781494},
    {-371.79602050781,343.24011230469,109.94289398193},
    {-328.02966308594,369.5881652832,110.0059967041},
    {-297.78378295898,379.82281494141,112.09733581543},
    {-214.04254150391,399.54815673828,111.28295135498},
    {-166.38412475586,423.90756225586,111.80576324463},
    {-595.52178955078,530.4072265625,107.75444793701},
    {-580.46954345703,491.81652832031,108.90315246582},
    {-622.94677734375,489.09628295898,108.8726272583},
    {-640.90930175781,520.54040527344,109.87781524658},
    {-667.09497070312,471.59414672852,114.13658905029},
    {-679.0517578125,512.03375244141,113.52607727051},
    {-717.73455810547,448.63119506836,106.90912628174},
    {-762.15594482422,430.9944152832,100.193801879886},
    {-784.75170898438,459.76312255859,100.38918304443},
    {-824.80749511719,421.98745727539,92.124290466309},
    {-842.76239013672,466.92111206055,87.596351623535},
    {-848.60217285156,508.60354614258,90.817268371582},
    {-884.37384033203,517.96209716797,92.442726135254},
    {-873.50500488281,562.60931396484,96.619430541992},
    {-907.43853759766,545.08917236328,100.20561981201},
    {-904.61096191406,588.2265625,101.18972015381},
    {-924.82958984375,561.35052490234,100.15752410889},
    {-974.40600585938,581.82147216797,103.14900970459},
    {-1022.6404418945,586.86846923828,103.42942047119},
    {-1107.6685791016,594.54034423828,104.45464324951},
    {-1090.033203125,548.52783203125,103.63327026367},
    {-1125.3405761719,548.32135009766,102.57225036621},
    {-1146.5313720703,545.87799072266,101.9075012207},
    {-1193.0972900391,564.02783203125,100.3394317627},
    {-1277.8841552734,497.07904052734,97.890533447266},
    {-1258.6275634766,446.72634887695,94.735687255859},
    {-1308.0904541016,449.00411987305,100.97008514404},
    {-1371.5209960938,443.93151855469,105.855941772463},
    {-1343.0603027344,481.44677734375,102.7620010376},
    {-1413.4934082031,462.1760559082,109.20855712891},
    {-1405.4810791016,526.7919921875,123.83116149902},
    {-1452.9125976562,545.54919433594,120.96368408203},
    {-1453.9412841797,512.28161621094,117.79638671875},
    {-1500.4788818359,523.02905273438,118.27211761475},
    {-1495.8796386719,436.99047851562,112.49787139893},
    {-1540.0415039062,420.54382324219,110.01399993896},
    {-1405.1030273438,561.96051025391,125.40614318848},
    {-1346.4556884766,560.63653564453,130.53153991699},
    {-1367.1362304688,610.75341796875,133.88981628418},
    {-1337.0361328125,606.17834472656,134.37973022461},
    {-1277.4411621094,629.99920654297,143.2476348877},
    {-1291.8166503906,650.43096923828,141.5016784668},
    {-1241.3099365234,674.49346923828,142.81190490723},
    {-1196.6665039062,693.25567626953,147.42718505859},
    {-1165.5965576172,726.83093261719,155.60673522949},
    {-1117.7878417969,761.4404296875,164.28869628906},
    {-1130.8295898438,784.53619384766,163.8874206543},
    {-1100.6265869141,797.86071777344,167.25604248047},
    {-1067.5520019531,795.75769042969,166.98561096191},
    {-1056.310546875,761.44128417969,167.31571960449},
    {-1065.0390625,726.82073974609,165.47459411621},
    {-1019.415222168,719.2998046875,163.99609375},
    {-931.46124267578,690.98907470703,153.46690368652},
    {-908.69592285156,693.75079345703,151.43586730957},
    {-884.71594238281,699.39251708984,151.27096557617},
    {-819.33367919922,696.61547851562,148.10855102539},
    {-765.70477294922,650.49499511719,145.69776916504},
    {-733.03894042969,593.75054931641,142.47764587402},
    {-704.19573974609,588.38818359375,142.28034973145},
    {-700.82244873047,647.01885986328,155.37046813965},
    {-747.26129150391,808.19146728516,215.0281829834},
    {-867.40130615234,784.96606445312,191.93363952637},
    {-912.25775146484,777.23944091797,187.0064239502},
    {-931.81597900391,808.93145751953,184.78077697754},
    {-962.73358154297,814.26861572266,177.75793457031},
    {-999.52709960938,816.96478271484,173.0495300293},
    {-972.35992431641,752.416015625,176.38136291504},
    {-658.46936035156,886.24102783203,229.30113220215},
    {-596.96588134766,851.60876464844,211.46688842773},
    {-536.77001953125,818.18383789062,197.51025390625},
    {-494.07702636719,795.95965576172,184.3405456543},
    {-495.80133056641,738.53625488281,163.03126525879},
    {-533.42999267578,709.54156494141,153.15475463867}
}

RegisterNetEvent("vRP:onJobChange")
AddEventHandler("vRP:onJobChange", function(job)
    job = job
    if job == 'Traficant de Metamfetamina' then
        canDoJob = true
    else
        canDoJob = false
        hasJob = false
        if blip then
            RemoveBlip(blip)
        end
    end
end)

RegisterNetEvent("fpt-metamfetamina:client:info")
AddEventHandler("fpt-metamfetamina:client:info", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Ai nevoie de Sulf si Efedrina pentru a crea Metamfetamina.', 7500, 'Solomon')
end)
	
RegisterNetEvent("fpt-metamfetamina:client:alexia")
AddEventHandler("fpt-metamfetamina:client:alexia", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Mi se spune Solomon, ma ocup de locatia asta. Mai ai multe intrebari?', 7500, 'Solomon')
end)

RegisterNetEvent("fpt-metamfetamina:client:locatie")
AddEventHandler("fpt-metamfetamina:client:locatie", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Nu, saptamanal locatia se inchiriaza catre oameni cu influenta la care o sa trebuiasca sa platesti taxe pentru a lucra.', 9500, 'Solomon')
end)

RegisterNetEvent("fpt-metamfetamina:client:gps")
AddEventHandler("fpt-metamfetamina:client:gps", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Trebuie sa te aprovizionezi de Efedrina de la Mega Mall sau You Tool si sulful de la Mina!', 7500, 'Solomon')
    SetNewWaypoint(2747.5100097656,3472.8933105469)
end)

RegisterNetEvent("fpt-metamfetamina:client:addUniforma")
AddEventHandler("fpt-metamfetamina:client:addUniforma", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Poftim uniforma, ia si schimba-te!', 7500, 'Solomon')
    local male = (GetEntityModel(PlayerPedId()))
    local uniforma = {}
    if male > 0	then
		uniforma = {
            ["drawable:3"] = {77,0}, -- Maini
			["drawable:1"] = {121,0}, -- Masca
			["drawable:4"] = {40,0}, -- Pantaloni
			["drawable:6"] = {25,0}, -- Incaltaminte
			["drawable:7"] = {127,0}, -- Lanturi / Cravata etc
			["drawable:8"] = {61,0}, -- Tricou
			["prop:0"] = {147,4}, -- Palarii
			["prop:1"] = {3,9}, -- Ochelari
			["drawable:11"] = {67,0} -- Geaca
        }
	elseif male < 0 then
		uniforma = {
            ["drawable:3"] = {88,0}, -- Maini
			["drawable:1"] = {121,0}, -- Masca
			["drawable:4"] = {40,0}, -- Pantaloni
			["drawable:6"] = {25,0}, -- Incaltaminte
			["drawable:7"] = {97,0}, -- Lanturi / Cravata etc
			["drawable:8"] = {42,0}, -- Tricou
			["prop:0"] = {146,4}, -- Palarii
			["prop:1"] = {19,9}, -- Ochelari
			["drawable:11"] = {61,0} -- Geaca
        }
	end
    exports['progressBars']:startUI(5000, 'Te schimbi...')
    playAnim('clothingtie', 'try_tie_negative_a', 3.0, -1, -1, 50, 0, false, false, false)
    Citizen.Wait(1700)
    playAnim('re@construction', 'out_of_breath', 3.0, -1, -1, 50, 0, false, false, false)
    Citizen.Wait(2300)
    ClearPedTasks(PlayerPedId())
    jobMetamfetaminaS.setUniforma{uniforma}
end)

RegisterNetEvent("fpt-metamfetamina:client:removeUniforma")
AddEventHandler("fpt-metamfetamina:client:removeUniforma", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Astea-s hainele tale!', 7500, 'Solomon')
    exports['progressBars']:startUI(3000, 'Te schimbi...')
    playAnim('clothingtie', 'try_tie_negative_a', 3.0, -1, -1, 50, 0, false, false, false)
    Citizen.Wait(1700)
    playAnim('re@construction', 'out_of_breath', 3.0, -1, -1, 50, 0, false, false, false)
    Citizen.Wait(1300)
    jobMetamfetaminaS.removeUniforma{}
end)

RegisterNetEvent("fpt-metamfetamina:client:addGroup")
AddEventHandler("fpt-metamfetamina:client:addGroup", function()
    jobMetamfetaminaS.setJob{true}
end)

RegisterNetEvent("fpt-metamfetamina:client:removeGroup")
AddEventHandler("fpt-metamfetamina:client:removeGroup", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Pacat... Sa inteleg ca nu iti plac banii?', 7500, 'Solomon')
    jobMetamfetaminaS.setJob{false}
end)

RegisterNetEvent("fpt-metamfetamina:client:angajat1")
AddEventHandler("fpt-metamfetamina:client:angajat1", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Diferite experimente pentru noi substante pe care vrem sa le punem pe piata neagra.', 7500, 'Savantul')
end)
    
RegisterNetEvent("fpt-metamfetamina:client:angajat2")
AddEventHandler("fpt-metamfetamina:client:angajat2", function()
    TriggerEvent('fplaytbank:notifications', 'inform', 'Vorbeste cu Solomon, el iti poate oferii mai multe informatii. Il gasesti in birou.', 7500, 'Savantul')
end)

local masinarii = {
    [1] = { 
        coords = vector3(5133.7749023438,-4610.3842773438,-4.1696467399597),
        heading = 348.54165649414,
        offsetX = - 4.88,
        offsetY = - 1.95,
        offsetZ = - 0.40,
        loc = 1,
        rot = 180.0,
        camCoords = vector3(5129.5815429688,-4613.876953125,-3.3799064159393)
    },
    [2] = {
        coords = vector3(5125.642578125,-4614.8764648438,-4.157470703125),
        heading = 162.57286071777,
        offsetX = 4.88,
        offsetY = 1.95,
        offsetZ = - 0.40,
        loc = 2,
        rot = 0.0,
        camCoords = vector3(5129.23828125,-4611.595703125,-3.3799064159393)
    }
}

local infoliatProcess = {
    coords = vector3(5123.30078125,-4618.5014648438,-4.6655960083008),
    heading = 161.70300292969,
}

function getPlayerPosition(crds)
    return GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), crds, true)
end

CreateThread(function()
    while true do
        Citizen.Wait(0)
        if canDoJob then
            inRange = false

            local distance2 = getPlayerPosition(infoliatProcess.coords)

            if distance2 < 1.5 then
                inRange = true
                DrawMarker(27, vector3(infoliatProcess.coords.x,infoliatProcess.coords.y,infoliatProcess.coords.z - 0.99), 0,0,0,0,0,0,0.5,0.5,0.2,255,255,255,100,0,0,0,0)
                if not notified then
                    notified = true
                    exports['fpt-textui']:Open('[E] Infoliaza Metamfetamina', 'darkblue', 'left')
                end
                if IsControlJustPressed(0,38) then
                    exports['fpt-textui']:Close()
                    jobMetamfetaminaF:infoliazaMetamfetamina(vector3(4509.1806640625,-4551.169921875,4.1719217300415),infoliatProcess.heading)
                end
            end

            for k,v in pairs(masinarii) do 
                local dst = getPlayerPosition(masinarii[k].coords)
                if dst < 1.5 then
                    inRange = true
                    if not notified then
                        notified = true
                        exports['fpt-textui']:Open('[E] Prepara Metamfetamina', 'darkblue', 'left')
                    end
                    DrawMarker(27, vector3(masinarii[k].coords.x,masinarii[k].coords.y,masinarii[k].coords.z - 1.0), 0,0,0,0,0,0,0.5,0.5,0.2,255,255,255,100,0,0,0,0)
                    if IsControlJustPressed(0, 38) then
                       
                           
                                exports['fpt-textui']:Close()
                                jobMetamfetaminaS.hasItems({"sulf", 2}, function (sulf)
                                    jobMetamfetaminaS.hasItems({"efedrina", 5}, function (efedrina)
                                        if sulf and efedrina then
                                            jobMetamfetaminaF:proceseazaMetamfetamina(masinarii[k].coords, masinarii[k].heading, masinarii[k].loc, masinarii[k].offsetX, masinarii[k].offsetY, masinarii[k].offsetZ, masinarii[k].rot, masinarii[k].camCoords)
                                        else    
                                            jobMetamfetaminaS.eliberatMasa{masinarii[k].loc}
                                            TriggerEvent("fplaytbank:notifications", "error", "Ai nevoie de 5x Efedrina si de 2x Sulf!", 7500, "FPlayT")
                                        end
                                    end)
                                end)
                            
                      
                    end
                end
            end

            if not hasJob then
                jobMetamfetaminaF:setUpJob()
            else
                local distLivrare = getPlayerPosition(position)
                if distLivrare < 10 then
                    inRange = true
                    DrawMarker(20,position.x,position.y,position.z + 0.1,0,0,0,0,0,0,0.35,0.35,-0.60,230,0,0,85,0)
                end
                if distLivrare < 1.5 then
                    inRange = true
                    if not showedLivrare then
                        exports['fpt-textui']:Open('[E] Bate la usa', 'darkblue', 'left')
                        showedLivrare = true
                    end
                    if IsControlJustPressed(0,38) then
                        jobMetamfetaminaF:livreaza()
                        exports['fpt-textui']:Close()
                    end
                else
                    if showedLivrare then
                        exports['fpt-textui']:Close()
                        showedLivrare = false
                    end
                end
            end
     
            if not inRange then
                Citizen.Wait(1000)
                if notified then
                    notified = false
                    exports['fpt-textui']:Close()
                end
            end
        else
            Citizen.Wait(1000)
        end
    end
end)

function jobMetamfetaminaF:setUpJob()
    hasJob = true
    if blip then
        RemoveBlip(blip)
    end
    local x,y,z = table.unpack(coordsLivrare[math.random(1,#coordsLivrare)])
    position = vector3(x,y,z)
    blip = AddBlipForCoord(position.x,position.y,position.z)
	SetBlipAsShortRange(blip, true)
	SetBlipRoute(blip, true)
	SetBlipScale(blip, 0.6)
	SetBlipSprite(blip, 501)
	SetBlipColour(blip, 57)
	SetBlipRouteColour(blip, 57)
    pachete = math.random(2,4)
    strada = GetStreetNameAtCoord(position.x, position.y, position.z, Citizen.ResultAsInteger(), Citizen.ResultAsInteger())
    numeStrada = GetStreetNameFromHashKey(strada)
    jobMetamfetaminaS.trimiteMail{numeStrada, pachete}
end

function jobMetamfetaminaF:livreaza()
    jobMetamfetaminaS.hasItems({"metamfetamina10g", pachete}, function (meta)
        if meta then
            exports['progressBars']:startUI(15000, "Livrezi...")
            local hash = GetHashKey("prop_meth_bag_01")
            RequestModel(hash)
            while not HasModelLoaded(hash) do
                Citizen.Wait(100)
                RequestModel(hash)
            end
            playAnim("timetable@jimmy@doorknock@", "knockdoor_idle", 2.0, 2.0, 5000, 51, 0, false, false, false)
            Citizen.Wait(5000)
            playAnim("anim@mugging@victim@toss_ped@", "throw_object_right_pocket_male", 2.0, 2.0, 2000, 51, 0, false, false, false)
            Citizen.Wait(300)
            local prop = CreateObject(hash, GetEntityCoords(PlayerPedId()), true, true, true)
            AttachEntityToEntity(prop, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 64016), 0.07, -0.01, -0.04, 0.0, 0.0, 190.0, true, true, false, false, 1, true)
            Citizen.Wait(1700)
            playAnim("tunf_iaa_mcs1-1", "mp_m_freemode_01^3_dual-1", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(3000)
            playAnim("mp_common", "givetake1_b", 2.0, 2.0, 3000, 1, 0, false, false, false)
            Citizen.Wait(1500)
            DeleteObject(prop)
            Citizen.Wait(3500)

            hasJob = false
            jobMetamfetaminaS.livreaza{pachete}
            ClearPedTasks(PlayerPedId())    
        else
            TriggerEvent('fplaytbank:notifications', 'error', 'Nu ai marfa la tine!', 7500, 'Client')    
        end
    end)
end

function jobMetamfetaminaF:proceseazaMetamfetamina(coord, heading, loc, offsetX, offsetY, offsetZ, rot, camCoords)
	local sceneCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
	RenderScriptCams(true, false, 0, 1, 0)
	SetCamCoord(sceneCam, camCoords.x, camCoords.y, camCoords.z)
	PointCamAtEntity(sceneCam, PlayerPedId(), 0.0, 0.0, 0.0, 1)
	RequestAnimDict('anim@amb@business@meth@meth_monitoring_cooking@cooking@')
	RequestModel('bkr_prop_meth_sacid')
	RequestModel('bkr_prop_meth_ammonia')
	while not HasAnimDictLoaded('anim@amb@business@meth@meth_monitoring_cooking@cooking@') and not HasModelLoaded("bkr_prop_meth_sacid") and not HasModelLoaded("bkr_prop_meth_ammonia") do Citizen.Wait(30) end
	local ammonia = CreateObject(GetHashKey("bkr_prop_meth_ammonia"), coord.x, coord.y, coord.z, true, false, false)
	local sacid = CreateObject(GetHashKey("bkr_prop_meth_sacid"), coord.x, coord.y, coord.z, true, false, false)
	SetEntityHeading(PlayerPedId(), heading)
	Citizen.Wait(100)
    exports['progressBars']:startUI(56000, "Prepari Metamfetamina...")
	local cookingScene = NetworkCreateSynchronisedScene(coord.x + offsetX, coord.y + offsetY, coord.z + offsetZ, 0.0, 0.0, rot, 2, false, false, 1065353216, 0, 1.3)
	NetworkAddPedToSynchronisedScene(PlayerPedId(), cookingScene, "anim@amb@business@meth@meth_monitoring_cooking@cooking@", "chemical_pour_short_cooker", 1.5, -4.0, 1, 16, 1148846080, 0)
	NetworkAddEntityToSynchronisedScene(ammonia, cookingScene, "anim@amb@business@meth@meth_monitoring_cooking@cooking@", "chemical_pour_short_ammonia", 4.0, -8.0, 1)
	NetworkAddEntityToSynchronisedScene(sacid, cookingScene, "anim@amb@business@meth@meth_monitoring_cooking@cooking@", "chemical_pour_short_sacid", 4.0, -8.0, 1)
	NetworkStartSynchronisedScene(cookingScene)
	Citizen.Wait(56000)
	NetworkStopSynchronisedScene(cookingScene)
	ClearFocus()
	RenderScriptCams(false, false, 0, 1, 0)
	DestroyCam(sceneCam, false)
	DeleteEntity(ammonia)
	DeleteEntity(sacid)
    jobMetamfetaminaS.finishedMetamfetamina{loc}
end

function jobMetamfetaminaF:infoliazaMetamfetamina(coord, heading)
  
            jobMetamfetaminaS.hasItems({"metamfetamina1g", 10}, function (meta)
                jobMetamfetaminaS.hasItems({"folieplastic", 1}, function (folie)
                    if meta and folie then
                        RequestAnimDict('anim@amb@business@meth@meth_smash_weight_check@')
                        while not HasAnimDictLoaded('anim@amb@business@meth@meth_smash_weight_check@') do Citizen.Wait(10) end
                        RequestModel('bkr_prop_meth_bigbag_04a')
                        RequestModel('bkr_prop_meth_bigbag_03a')
                        RequestModel('bkr_prop_fakeid_clipboard_01a')
                        RequestModel('bkr_prop_meth_openbag_02')
                        RequestModel('bkr_prop_fakeid_penclipboard')
                        RequestModel('bkr_prop_coke_scale_01')
                        RequestModel('bkr_prop_meth_scoop_01a')
                        while not HasModelLoaded('bkr_prop_meth_bigbag_04a') and not HasModelLoaded('bkr_prop_meth_bigbag_03a') and not HasModelLoaded('bkr_prop_fakeid_clipboard_01a') and not HasModelLoaded('bkr_prop_meth_openbag_02') and not HasModelLoaded('bkr_prop_fakeid_penclipboard') and not HasModelLoaded('bkr_prop_coke_scale_01') and not HasModelLoaded('bkr_prop_meth_scoop_01a') do 
                            Citizen.Wait(50)
                        end
                        local animDict = "anim@amb@business@meth@meth_smash_weight_check@"
                        SetEntityHeading(PlayerPedId(), heading)
                                           local packageScene = NetworkCreateSynchronisedScene(coord.x+4.72, coord.y+1.24, coord.z-0.99, 0.0, 0.0, 175.0, 2, false, false, 1065353216, 0, 1.3)
                        local packageScene2 = NetworkCreateSynchronisedScene(coord.x+4.72, coord.y+1.24, coord.z-0.99, 0.0, 0.0, 175.0, 2, false, false, 1065353216, 0, 1.3)
                        local packageScene3 = NetworkCreateSynchronisedScene(coord.x+4.72, coord.y+1.24, coord.z-0.99, 0.0, 0.0, 175.0, 2, false, false, 1065353216, 0, 1.3)
                        local packageScene4 = NetworkCreateSynchronisedScene(coord.x+4.72, coord.y+1.24, coord.z-0.99, 0.0, 0.0, 175.0, 2, false, false, 1065353216, 0, 1.3)
                        local packageScene5 = NetworkCreateSynchronisedScene(coord.x+4.72, coord.y+1.24, coord.z-0.99, 0.0, 0.0, 175.0, 2, false, false, 1065353216, 0, 1.3)
                        Citizen.Wait(100) 
                        local box01 = CreateObject(GetHashKey("bkr_prop_meth_bigbag_04a"), coord, 1, 0, 0)
                        local box02 = CreateObject(GetHashKey("bkr_prop_meth_bigbag_03a"), coord, 1, 0, 0)
                        local clipboard = CreateObject(GetHashKey("bkr_prop_fakeid_clipboard_01a"), coord, 1, 0, 0)
                        local methbag01 = CreateObject(GetHashKey("bkr_prop_meth_openbag_02"), coord, 1, 0, 0)
                        local methbag02 = CreateObject(GetHashKey("bkr_prop_meth_openbag_02"), coord, 1, 0, 0)
                        local methbag03 = CreateObject(GetHashKey("bkr_prop_meth_openbag_02"), coord, 1, 0, 0)
                        local methbag04 = CreateObject(GetHashKey("bkr_prop_meth_openbag_02"), coord, 1, 0, 0)
                        local methbag05 = CreateObject(GetHashKey("bkr_prop_meth_openbag_02"), coord, 1, 0, 0)
                        local methbag06 = CreateObject(GetHashKey("bkr_prop_meth_openbag_02"), coord, 1, 0, 0)
                        local methbag07 = CreateObject(GetHashKey("bkr_prop_meth_openbag_02"), coord, 1, 0, 0)
                        local pencil = CreateObject(GetHashKey("bkr_prop_fakeid_penclipboard"), coord, 1, 0, 0)
                        local scale = CreateObject(GetHashKey("bkr_prop_coke_scale_01"), coord, 1, 0, 0)
                        local scoop = CreateObject(GetHashKey("bkr_prop_meth_scoop_01a"), coord, 1, 0, 0)
                        exports['progressBars']:startUI(39800, "Impachetezi Metamfetamina")
                        NetworkAddPedToSynchronisedScene(PlayerPedId(), packageScene, animDict, "break_weigh_v3_char01", 1.5, -4.0, 1, 16, 1148846080, 0)
                        NetworkAddEntityToSynchronisedScene(box01, packageScene, animDict, "break_weigh_v3_box01", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(box02, packageScene, animDict, "break_weigh_v3_box01^1", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(clipboard, packageScene, animDict, "break_weigh_v3_clipboard", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(methbag01, packageScene2, animDict, "break_weigh_v3_methbag01", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(methbag02, packageScene2, animDict, "break_weigh_v3_methbag01^1", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(methbag03, packageScene2, animDict, "break_weigh_v3_methbag01^2", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(methbag04, packageScene3, animDict, "break_weigh_v3_methbag01^3", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(methbag05, packageScene3, animDict, "break_weigh_v3_methbag01^4", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(methbag06, packageScene3, animDict, "break_weigh_v3_methbag01^5", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(methbag07, packageScene4, animDict, "break_weigh_v3_methbag01^6", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(pencil, packageScene4, animDict, "break_weigh_v3_pen", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(scale, packageScene4, animDict, "break_weigh_v3_scale", 4.0, -8.0, 1)
                        NetworkAddEntityToSynchronisedScene(scoop, packageScene5, animDict, "break_weigh_v3_scoop", 4.0, -8.0, 1)
                        NetworkStartSynchronisedScene(packageScene)
                        NetworkStartSynchronisedScene(packageScene2)
                        NetworkStartSynchronisedScene(packageScene3)
                        NetworkStartSynchronisedScene(packageScene4)
                        NetworkStartSynchronisedScene(packageScene5)
                        Citizen.Wait(39800)
                        NetworkStopSynchronisedScene(packageScene)
                        NetworkStopSynchronisedScene(packageScene2)
                        NetworkStopSynchronisedScene(packageScene3)
                        NetworkStopSynchronisedScene(packageScene4)
                        NetworkStopSynchronisedScene(packageScene5)
                        DeleteEntity(box02)
                        DeleteEntity(box01)
                        DeleteEntity(clipboard)
                        DeleteEntity(methbag01)
                        DeleteEntity(methbag02)
                        DeleteEntity(methbag03)
                        DeleteEntity(methbag04)
                        DeleteEntity(methbag05)
                        DeleteEntity(methbag06)
                        DeleteEntity(methbag07)
                        DeleteEntity(pencil)
                        DeleteEntity(scale)
                        DeleteEntity(scoop)
                        jobMetamfetaminaS.finishedInfoliat{}
                    else
                        jobMetamfetaminaS.eliberatInfoliere{}
                        TriggerEvent("fplaytbank:notifications", "error", "Ai nevoie de 10 grame de metamfetamina si de folie de plastic!", 7500, "FPlayT")
                    end
                end)
            end)
  
end