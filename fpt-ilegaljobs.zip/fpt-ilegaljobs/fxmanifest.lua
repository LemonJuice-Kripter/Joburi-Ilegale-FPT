fx_version("adamant");
game("gta5");


client_scripts({ "@vrp/client/Proxy.lua"; "@vrp/client/Tunnel.lua"; "utils/utils-c.lua"; "**/*-client.lua" });

server_scripts({ "@vrp/lib/utils.lua"; "cfg.lua"; "utils/utils-s.lua"; "**/*-server.lua" });

escrow_ignore({ "utils/utils-c.lua"; "**/*-client.lua"; "cfg.lua" });
